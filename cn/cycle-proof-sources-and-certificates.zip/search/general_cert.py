"""Verify an odd-cycle metric upper bound exactly, using only the standard library."""
from argparse import ArgumentParser
from collections import Counter
from fractions import Fraction as Q
from functools import lru_cache
from itertools import combinations, permutations
import json
from pathlib import Path


def check(condition, message):
    if not condition:
        raise ValueError(message)


class Rules:
    def __init__(self, n):
        check(type(n) is int and n >= 5 and n % 2 == 1, "odd n >= 5 required")
        self.n = n
        self.pairs = list(combinations(range(n), 2))
        self.index = {pair:i for i,pair in enumerate(self.pairs)}
        self.dim = len(self.pairs)
        self.edges = [self.ix(i, (i+1)%n) for i in range(n)]
        self.sym = {(edge, self.edges[0]) for edge in self.edges[1:]}
        self.sym.add((self.edges[1], self.edges[-1]))
        self.target = Q(n-1) + Q(1,4*(n-2))
        self.match = set()
        for a,b,c,d in permutations(range(n),4):
            self.match.add(tuple(self.ix(i,j) for i,j in [(a,b),(c,d),(a,c),(b,d),(a,d),(b,c)]))

    def ix(self,i,j):
        return self.index[tuple(sorted((i,j)))]

    @lru_cache(None)
    def static(self,rule):
        op,*args=rule
        if op=="t":
            i,j,h=args
            return [(self.ix(i,h),1),(self.ix(i,j),-1),(self.ix(j,h),-1)],0
        if op=="cp":
            check(len(args)==self.n and min(args)>=0 and sum(args)>0,"invalid copositive test")
            s=sum(args)**2
            return [(t,Q(4*args[i]*args[j],s)) for t,(i,j) in enumerate(self.pairs) if args[i]*args[j]],1
        if op=="sym":
            i,j=args
            check((i,j) in self.sym,"unproved symmetry assumption")
            return [(i,1),(j,-1)],0
        if op=="c5":
            check(len(args)==len(set(args))==5,"invalid pentagon")
            return [(self.ix(v,args[i-1]),1) for i,v in enumerate(args)],Q(49,12)
        raise ValueError("unknown static rule")

    def row(self,rule,lo,hi):
        op,*a=rule
        if op in ("ub","lb"):
            i,=a
            check(0<=i<self.dim,"coordinate out of range")
            return ([(i,1)],hi[i]) if op=="ub" else ([(i,-1)],-lo[i])
        if op not in ("p","mix"):
            return self.static(rule)
        x,y,u,v,w,z=a[:6]
        check(tuple(a[:6]) in self.match,"invalid ordered four-point matching")
        if op=="mix":
            sign,=a[6:]
            check(sign in (-1,1),"invalid sign")
            cross=max(lo[u],lo[v],lo[w],lo[z])
            sums=min(lo[u]+lo[z],lo[v]+lo[w])
            K=Q(2)
            if cross:
                K=min(K,2*hi[y]/cross)
            if sums:
                K=min(K,max(1,2*hi[y]/sums))
            return [(u,sign),(v,sign),(w,-sign),(z,-sign),(x,-K)],0
        bits=a[6:]
        check(len(bits)==3 and all(b in (0,1) for b in bits),"invalid envelope flag")
        terms=[]
        b=Q(0)
        for t,(i,j) in enumerate([(x,y),(u,v),(w,z)]):
            flag=bits[t]
            sign=1 if t==0 else -1
            pi=(lo,hi)[flag][i]
            pj=(lo,hi)[flag if t==0 else 1-flag][j]
            terms.extend([(i,sign*pj),(j,sign*pi)])
            b+=sign*pi*pj
        return terms,b

    def value(self,rule_list,multipliers,lo,hi,empty=False):
        residual=[Q(j in self.edges and not empty) for j in range(self.dim)]
        bound=Q(0)
        for idx,num,den in multipliers:
            check(type(idx) is int and 0<=idx<len(rule_list) and type(num) is int
                  and type(den) is int and num>0 and den>0,"invalid dual multiplier")
            weight=Q(num,den)
            row,b=self.row(tuple(rule_list[idx]),lo,hi)
            bound+=weight*b
            for j,a in row:
                residual[j]-=weight*a
        return bound+sum(a*(hi[j] if a>0 else lo[j]) for j,a in enumerate(residual))


def verify(document):
    rules=Rules(document["n"])
    dictionary=document["rules"]
    for entry in dictionary:
        check(isinstance(entry,list) and isinstance(entry[0],str)
              and all(type(v) is int for v in entry[1:]),"invalid row argument")
    counts=Counter()
    def visit(node,lo,hi,depth=0):
        counts["max_depth"]=max(counts["max_depth"],depth)
        if node[0]=="s":
            _,i,left,right=node
            check(type(i) is int and 0<=i<rules.dim,"invalid split")
            mid=(lo[i]+hi[i])/2
            lh,rl=list(hi),list(lo)
            lh[i]=rl[i]=mid
            counts["splits"]+=1
            visit(left,lo,lh,depth+1)
            visit(right,rl,hi,depth+1)
        else:
            op,terms=node
            check(op in ("b","e"),"invalid leaf")
            val=rules.value(dictionary,terms,lo,hi,op=="e")
            check(val<0 if op=="e" else val<=rules.target,
                  f"invalid leaf {op} at depth {depth}: {val}")
            counts[op]+=1
            counts["terms"]+=len(terms)
    visit(document["tree"],[Q(0)]*rules.dim,[Q(1)]*rules.dim)
    return rules.target, dict(counts)


if __name__=="__main__":
    p=ArgumentParser(description=__doc__)
    p.add_argument("certificate",type=Path)
    args=p.parse_args()
    print(verify(json.loads(args.certificate.read_text(encoding="ascii"))))
