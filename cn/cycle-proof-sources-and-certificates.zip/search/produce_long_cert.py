"""Search for and validate a dyadic-box proof of the odd-cycle upper bound."""
import argparse
from collections import Counter
from fractions import Fraction as Q
import json
from pathlib import Path
from time import monotonic

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import hstack
from sympy import Matrix, Rational
from general_cert import Rules, verify
from probe_long_cycle import Search


class Producer(Search):
    def __init__(self,n):
        super().__init__(n)
        self.rulebook=Rules(n)
        self.ids={}
        self.dictionary=[]
        self.count=Counter()
        self.start=monotonic()

    def register(self,label):
        rule=(label[0],*map(int,label[1:]))
        if rule not in self.ids:
            self.ids[rule]=len(self.dictionary)
            self.dictionary.append(rule)
        return self.ids[rule]

    def prove(self,lo,hi,res):
        A,b,labels=self.last_lp
        empty=not res.success
        if empty:
            if res.status!=2:
                raise RuntimeError(res.message)
            L=hstack([A,-np.ones((len(labels),1))],format="csr")
            res=linprog([0]*len(lo)+[1],A_ub=L,b_ub=b,
                        bounds=list(zip(lo,hi))+[(None,None)],method="highs")
            if not res.success or res.fun<=0:
                return None
        lo=list(map(Q,lo))
        hi=list(map(Q,hi))
        sparse=[(self.register(labels[i]),-v) for i,v in enumerate(res.ineqlin.marginals) if v < -1e-12]
        op="e" if empty else "b"
        bound_fn=lambda s:self.rulebook.value(self.dictionary,s,lo,hi,empty)
        def passing(s):
            x=bound_fn(s)
            return x<0 if empty else x<=self.rulebook.target
        for den in (10000,10**10,10**21):
            terms=[]
            for idx,weight in sparse:
                w=Q(float(weight)).limit_denominator(den)
                if w:
                    terms.append([idx,w.numerator,w.denominator])
            if passing(terms):
                return [op,terms]
        if empty:
            return None
        active=[idx for idx,w in sparse]
        for j,(l,h) in enumerate(zip(res.lower.marginals,res.upper.marginals)):
            if l>1e-12:
                active.append(self.register(("lb",j)))
            if h< -1e-12:
                active.append(self.register(("ub",j)))
        # Solve the dual equations on the floating optimizer's support.
        # The resulting identity is rechecked by the rational verifier.
        columns=[]
        for idx in active:
            row,offset=self.rulebook.row(self.dictionary[idx],lo,hi)
            vals=[Q(0)]*len(lo)
            for j,v in row:
                vals[j]+=v
            columns.append(vals)
        try:
            weights,params=Matrix(columns).T.gauss_jordan_solve(
                Matrix([int(i in self.rulebook.edges) for i in range(len(lo))]))
        except ValueError:
            return None
        if params.rows:
            weights=weights.subs({p:0 for p in params})
        if any(w<0 for w in weights):
            return None
        terms=[[idx,int(w.p),int(w.q)] for idx,w in zip(active,weights) if w>0]
        if passing(terms):
            self.count["linear_solve"]+=1
            return [op,terms]
        return None

    def visit(self,lo,hi,depth=0):
        self.count["nodes"]+=1
        res=self.relax(lo,hi)
        if not res.success or -res.fun<=self.target+1e-8:
            leaf=self.prove(lo,hi,res)
            if leaf:
                self.count[leaf[0]]+=1
                return leaf
            self.count["retry"]+=1
            if not res.success:
                raise ArithmeticError(f"infeasible box with no exact certificate at depth {depth}")
        if depth>=100:
            raise ArithmeticError(f"unresolved box at depth {depth} upper {-res.fun}")
        if self.count["nodes"]%200<2:
            print(dict(self.count),"depth",depth,"seconds",round(monotonic()-self.start,2),flush=True)
        gap=(hi-res.x)*(res.x-lo)
        axis=int(np.argmax(gap+.02*(hi-lo)))
        mid=(hi[axis]+lo[axis])/2
        lh,rl=hi.copy(),lo.copy()
        lh[axis]=rl[axis]=mid
        return ["s",axis,self.visit(lo,lh,depth+1),self.visit(rl,hi,depth+1)]

    def export(self):
        dim=len(self.pairs)
        tree=self.visit(np.zeros(dim),np.ones(dim))
        return {"n":self.n,"rules":[list(rule) for rule in self.dictionary],"tree":tree}

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("n",type=int)
    p.add_argument("output",type=Path)
    args=p.parse_args()
    search=Producer(args.n)
    document=search.export()
    print(verify(document),dict(search.count),flush=True)
    args.output.write_text(json.dumps(document,separators=(",",":")),encoding="ascii")
