"""Generate a fixed-order proof, separating the dynamic four-point rows."""
from argparse import ArgumentParser
import json
from pathlib import Path
import sys

from separated import Separated
folder=Path(__file__).resolve().parent
sys.path.insert(0,str(folder.parent/"general-pricing"))
from generate9 import Generate9

class FastProducer(Generate9):
    relax=Separated.relax


if __name__=="__main__":
    p=ArgumentParser(description=__doc__)
    p.add_argument("n",type=int)
    p.add_argument("output",type=Path)
    a=p.parse_args()
    search=FastProducer(2**22,False,True,a.n,True)
    search.last_used=set()
    document=search.export()
    a.output.write_text(json.dumps(document,separators=(",",":")),encoding="ascii")
    print(dict(search.count),"rules",len(document["rules"]),flush=True)
