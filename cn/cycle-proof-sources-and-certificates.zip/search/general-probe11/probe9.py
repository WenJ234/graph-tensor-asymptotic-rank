"""Explore C9 using max-plus separation of every short closed walk.

The --seven option uses the prospective exact C7 theorem as an assumption.
No floating-point node count is a proof.
"""
import argparse
from pathlib import Path
import sys
from time import monotonic

import numpy as np
from scipy.optimize import minimize
from scipy.sparse import csr_matrix

from base_search import Search


class WalkSearch(Search):
    def __init__(self, n, seven, shortest, heaviest, tripod, sharpen=False):
        super().__init__(n)
        self.caps = [(5, 49/12)]
        if seven:
            self.caps.append((7, 121/20))
            if n>=11:
                self.caps.append((9,225/28))
        self.walk_rows = set()
        self.heaviest = heaviest
        self.sharpen = sharpen
        self.tripod_regions = []
        if not shortest:
            self.add(-self.vec(0,1), -self.target/n, ("longest-floor",))
            for i in range(1, n):
                self.add(-(n-1)*self.vec(0,1)-self.vec(i,i+1), -self.target,
                         ("longest-bound", i))
        if heaviest:
            self.caps.append((n, 0))
            for i in range(n):
                a, b, c = (i-1) % n, i, (i+1) % n
                for j in range(n):
                    if j in (a, b, c):
                        continue
                    self.add(self.vec(a, j)+self.vec(j, c)-self.vec(a, b)-self.vec(b, c),
                             0, ("replace", a, b, c, j))
            for i in range(n):
                for j in range(i):
                    a, b, c, d = i, (i+1) % n, j, (j+1) % n
                    if len({a, b, c, d}) == 4:
                        self.add(self.vec(a, c)+self.vec(b, d)-self.vec(a, b)-self.vec(c, d),
                                 0, ("two-opt", a, b, c, d))
        if tripod:
            k, x, K = n//2, n-2, 4/3
            for c in range(n):
                a = [(c+1+2*i) % n for i in range(k)]
                b = [(c+2+2*i) % n for i in range(k)]
                pa = sum(self.vec(a[0], v) for v in a[1:])
                pb = sum(self.vec(b[-1], v) for v in b[:-1])
                ca, cb, r = self.vec(c, a[0]), self.vec(c, b[-1]), self.vec(a[0], b[-1])
                self.add(-pa-pb, -1/(512*x), ("tripod-radius", c))
                self.tripod_regions.append(np.array([
                    2*(cb+pb)-K*(2*ca-pa), 2*(ca+pa)-K*(2*cb-pb),
                    2*(cb+pb)-K*(2*r-2*pb-pa), 2*(ca+pa)-K*(2*r-2*pa-pb),
                    (x/k)*pb-(x/k-K)*(r-pa-pb), (x/k)*pa-(x/k-K)*(r-pa-pb)]))
        if shortest:
            triangles = n*(n-1)*(n-2)//2
            for i in range(triangles, triangles+n-1):
                self.rows[i] *= -1
            self.rows[triangles+n-1] *= -1

    def separate_walks(self, x):
        n = self.n
        matrix = np.zeros((n, n))
        for (u, v), distance in zip(self.pairs, x):
            matrix[u, v] = matrix[v, u] = distance
        dp = matrix
        hops = {}
        added = 0
        caps = dict(self.caps)
        for length in range(2, max(caps)):
            candidates = matrix[:, :, None]+dp[None, :, :]
            hops[length] = candidates.argmax(axis=1)
            dp = candidates.max(axis=1)
            if length+1 not in caps:
                continue
            own_walk = self.heaviest and length+1 == n
            cap = -self.obj @ x if own_walk else caps[length+1]
            for u, v in zip(*np.triu(matrix+dp > cap+1e-7, 1).nonzero()):
                trail = [u]
                for rem in range(length, 1, -1):
                    trail.append(hops[rem][trail[-1], v])
                trail.extend([v, u])
                indices = tuple(sorted(self.ix(a, b) for a, b in zip(trail, trail[1:]) if a != b))
                if (length, indices) in self.walk_rows:
                    continue
                self.walk_rows.add((length, indices))
                vec = np.bincount(indices, minlength=len(self.pairs))
                self.add(vec+self.obj if own_walk else vec, 0 if own_walk else cap,
                         ("walk", length+1, *trail[:-1]))
                added += 1
        return added

    def find_cut(self, x):
        walks = self.separate_walks(x)
        cp = super().find_cut(x)
        if self.sharpen and not cp:
            mat = np.zeros((self.n, self.n))
            for (i,j), d in zip(self.pairs, x):
                mat[i,j] = mat[j,i] = d
            p0 = np.full(self.n, 1/self.n)
            opt = minimize(lambda p:-2*p@mat@p, p0, jac=lambda p:-4*mat@p,
                           constraints=[{"type":"eq","fun":lambda p:p.sum()-1,
                                         "jac":lambda p:np.ones(self.n)}],
                           bounds=[(0,1)]*self.n, method="SLSQP",
                           options={"maxiter":100,"ftol":1.e-13})
            if -opt.fun > 1+3e-8:
                weights = tuple(np.rint(np.maximum(0,opt.x)*1000000).astype(int))
                if weights not in self.known:
                    self.cp(weights)
                    cp = True
        return walks or cp

    def tighten(self, lo, hi):
        # Propagate every static linear inequality, the exact objective
        # lower bound, and the three-point CP lens to the current box.
        A = csr_matrix(np.vstack([self.rows, self.obj]))
        idx, vals = A.indices, A.data
        nonempty = np.diff(A.indptr) > 0
        if not nonempty.all():
            A = A[nonempty]
            idx, vals = A.indices, A.data
        rhs = np.append(self.rhs, -self.target)[nonempty]
        row = np.repeat(np.arange(A.shape[0]),np.diff(A.indptr))
        pos = vals>0
        tr = np.array([(self.ix(i,k), self.ix(i,j), self.ix(j,k)) for i in range(self.n)
                      for k in range(i) for j in range(self.n) if j not in (i,k)]).T
        rid, qid, sid = tr
        for rnd in range(12):
            best = np.where(pos, lo[idx], hi[idx])
            margin = rhs-np.add.reduceat(vals*best, A.indptr[:-1])
            if margin.min() < -1e-7:
                return None, None
            interval = best + (margin[row]+2.e-10)/vals
            old_width = (hi-lo).sum()
            np.minimum.at(hi,idx[pos],interval[pos])
            np.maximum.at(lo,idx[~pos],interval[~pos])
            cap = (np.sqrt(np.maximum(0.,1-lo[qid]))+np.sqrt(np.maximum(0.,1-lo[sid])))**2
            lx,ly=np.clip(lo[qid],0.,1.),np.clip(lo[sid],0.,1.)
            strong=(np.sqrt(lx*(1-ly))+np.sqrt(ly*(1-lx)))**2
            cap=np.minimum(cap,np.where(lx+ly>1,strong,1.))
            np.minimum.at(hi,rid,cap+2.e-10)
            if (lo-hi).max() > 1e-7:
                return None,None
            if old_width-(hi-lo).sum() < 1.e-6:
                break
        return lo, np.maximum(lo, hi)

    def run_regions(self, limit, report):
        dim, timer = len(self.pairs), monotonic()
        stack = [(np.zeros(dim), np.ones(dim), 0, (), frozenset())]
        counts = {"empty":0, "closed":0, "split":0, "region":0}
        for step in range(limit):
            if not stack:
                break
            lo, hi, depth, local, used = stack.pop()
            old = self.rows, self.rhs, self.labels
            for idx, prop in enumerate(("rows", "rhs", "labels")):
                added = [[r for r in local], [0]*len(local), [("region",)]*len(local)][idx]
                setattr(self, prop, list(old[idx])+added)
            before = len(self.rows)
            if self.sharpen:
                lo, hi = self.tighten(lo.copy(), hi.copy())
            if lo is None:
                from types import SimpleNamespace
                res = SimpleNamespace(success=False)
            else:
                res = self.relax(lo, hi)
            for idx, prop in enumerate(("rows", "rhs", "labels")):
                old[idx].extend(getattr(self, prop)[before:])
                setattr(self, prop, old[idx])
            if not res.success or -res.fun < self.target-1e-8:
                counts["empty"] += 1
            elif -res.fun <= self.target+1e-9:
                counts["closed"] += 1
            else:
                x = res.x
                preferred = [((region @ x).max(), c) for c, region in enumerate(self.tripod_regions) if c not in used]
                score, c = min(preferred, default=(1, -1))
                if score < -1e-7:
                    region = self.tripod_regions[c]
                    for j in reversed(range(len(region))):
                        stack.append((lo, hi, depth+1, (*local, *region[:j], -region[j]), used | {c}))
                    counts["region"] += 1
                elif depth >= 150:
                    print("Near-target unresolved", depth, -res.fun, flush=True)
                    break
                else:
                    gap = (hi-x)*(x-lo)
                    axis = int(np.argmax(gap+.02*(hi-lo)))
                    mid = (hi[axis]+lo[axis])/2
                    hl, lr = hi.copy(), lo.copy()
                    hl[axis] = lr[axis] = mid
                    stack.extend([(lr, hi, depth+1, local, used), (lo, hl, depth+1, local, used)])
                    counts["split"] += 1
            if step % report == 0:
                print(step, counts, "open", len(stack), "depth", depth,
                      "upper", None if not res.success else -res.fun,
                      "secs", round(monotonic()-timer, 2), flush=True)
        print("Final", counts, "open", len(stack), flush=True)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--n", type=int, default=9)
    p.add_argument("--limit", type=int, default=1000)
    p.add_argument("--report", type=int, default=100)
    p.add_argument("--seven", action="store_true")
    p.add_argument("--shortest", action="store_true")
    p.add_argument("--heaviest", action="store_true")
    p.add_argument("--tripod", action="store_true")
    p.add_argument("--sharpen", action="store_true")
    args = p.parse_args()
    search = WalkSearch(args.n, args.seven, args.shortest, args.heaviest, args.tripod, args.sharpen)
    if args.tripod or args.sharpen:
        search.run_regions(args.limit, args.report)
    else:
        search.run(args.limit, args.report)
    print("Short-walk rows added", len(search.walk_rows))
