"""Explore box coverage for normalized odd-cycle wire distances.

LP values and early coverage in this file are exploratory, never certificates.
"""
import argparse
from itertools import combinations, permutations, product
from math import comb
import json
from pathlib import Path
from time import monotonic
import numpy as np
from scipy.optimize import linprog, minimize
from scipy.sparse import csr_matrix


class Search:
    def __init__(self, n):
        self.n = n
        self.k = n//2
        self.target = n-1+1/(4*(n-2))
        self.pairs = list(combinations(range(n), 2))
        self.idx = {pair:i for i,pair in enumerate(self.pairs)}
        self.eye = np.eye(len(self.pairs))
        self.obj = -sum(self.vec(i,i+1) for i in range(n))
        self.rows = []
        self.rhs = []
        self.labels = []
        for i,j,h in permutations(range(n),3):
            if i<h:
                self.add(self.vec(i,h)-self.vec(i,j)-self.vec(j,h),0,("t",i,j,h))
        # Choose a longest cycle edge, then the longer of its two neighbors.
        for i in range(1,n):
            self.add(self.vec(i,i+1)-self.vec(0,1),0,("sym",self.ix(i,i+1),self.ix(0,1)))
        self.add(self.vec(1,2)-self.vec(-1,0),0,("sym",self.ix(1,2),self.ix(-1,0)))
        self.known=set()
        for size in [2,3,4,n]:
            for face in combinations(range(n),size):
                support=set(face)
                self.cp(tuple(int(i in support) for i in range(n)))
        for i in range(n):
            self.cp([self.k if j==i else n-2 for j in range(n)])
            for j in range(i):
                for h in range(n):
                    if h not in (i,j):
                        self.cp([n-2 if v in (i,j) else 1 if v==h else 0 for v in range(n)])
        # Exact C5 theorem, also valid for any five-site restriction.
        for five in (combinations(range(n),5) if n < 10 else ()):
            for tail in permutations(five[1:]):
                if tail[0]>tail[-1]:
                    continue
                cycle=(five[0],)+tail
                self.add(sum(self.vec(v,cycle[j-1]) for j,v in enumerate(cycle)),49/12,("c5",*cycle))
        # Store the three possible products in each four-point inequality.
        self.quads=[]
        for a,b,c,d in combinations(range(n),4):
            for x,y,z in [(b,c,d),(c,b,d),(d,b,c)]:
                self.quads.append(tuple(self.ix(i,j) for i,j in [
                    (a,x),(y,z),(a,y),(x,z),(a,z),(x,y)]))
        self.quads=np.array(self.quads)
        self.pts=[]
        for ends in product((0,1),repeat=3):
            self.pts.append((ends[0],ends[0],ends[1],1-ends[1],ends[2],1-ends[2]))
        self.counts={"empty":0,"closed":0,"split":0,"unresolved":0}

    def ix(self,i,j):
        return self.idx[tuple(sorted((i%self.n,j%self.n)))]

    def vec(self,i,j):
        return self.eye[self.ix(i,j)]

    def add(self,row,b,label):
        self.rows.append(row)
        self.rhs.append(b)
        self.labels.append(label)

    def cp(self,weights):
        weights=tuple(weights)
        if weights not in self.known:
            self.known.add(weights)
            p=np.array(weights)/sum(weights)
            self.add(np.array([4*p[i]*p[j] for i,j in self.pairs]),1.,("cp",*map(int,weights)))

    def find_cut(self,x):
        n=self.n
        m=np.zeros((n,n))
        for (i,j),d in zip(self.pairs,x):
            m[i,j]=m[j,i]=d
        # Concave restriction is not guaranteed. Any violated nonnegative
        # weight is a correct cut, independent of this search heuristic.
        p=np.full(n,1/n)
        for _ in range(15):
            v=m@p
            best=int(np.argmax(v))
            gap=v[best]-p@v
            if gap<1e-8:
                break
            d=-p.copy()
            d[best]+=1
            alpha=min(1,gap/max(1e-12,-d@m@d))
            p=p+alpha*d
        if 2*p@m@p>1.0000003:
            w=tuple(np.rint(p*100000).astype(int))
            if w not in self.known:
                self.cp(w)
                return True
        return False

    def relax(self,lo,hi):
        # For X*Y, the affine support at (p,q) has coefficients (q,p)
        # and constant -p*q. Build the eight endpoint combinations.
        ix=self.quads
        eye=self.eye
        extra=[]
        extra_b=[]
        extra_labels=[]
        for bits in self.pts:
            selected=[(lo,hi)[bit][ix[:,j]] for j,bit in enumerate(bits)]
            positive=selected[1][:,None]*eye[ix[:,0]]+selected[0][:,None]*eye[ix[:,1]]
            rhs=selected[0]*selected[1]
            for k in [2,4]:
                positive-=selected[k+1][:,None]*eye[ix[:,k]]+selected[k][:,None]*eye[ix[:,k+1]]
                rhs-=selected[k]*selected[k+1]
            extra.append(positive)
            extra_b.append(rhs)
            extra_labels.extend(("p",*indices,bits[0],bits[2],bits[4]) for indices in ix)
        # Mixed four-point differences. The Ptolemy numerator and the
        # product of two Lipschitz differences are bounded by the product
        # of the two within-pair distances. Any of four cross distances
        # can be the denominator. The distance-difference version can be
        # used with a coefficient >=1 if both sums of cross distances are
        # large. Both tests are valid over the entire closed box.
        for x,y,u,v,w,z in ix:
            delta=eye[u]+eye[v]-eye[w]-eye[z]
            for short,other,s1,s2 in [(x,y,(u,z),(v,w)),(y,x,(u,w),(v,z))]:
                maxlo=max(lo[u],lo[v],lo[w],lo[z])
                sums=min(lo[s1[0]]+lo[s1[1]],lo[s2[0]]+lo[s2[1]])
                coeff=min(2,2*hi[other]/max(maxlo,1e-12),
                          max(1,2*hi[other]/max(sums,1e-12)))
                if coeff<1.9999999:
                    for sign in [1,-1]:
                        extra.append((sign*delta-coeff*eye[short])[None,:])
                        extra_b.append(np.array([0.]))
                        orientation=(x,y,u,v,w,z) if short==x else (y,x,u,v,z,w)
                        extra_labels.append(("mix",*orientation,sign))
        for _ in range(5):
            A=csr_matrix(np.vstack([self.rows]+extra))
            b=np.concatenate([self.rhs]+extra_b)
            self.last_lp=A,b,self.labels+extra_labels
            res=linprog(self.obj,A_ub=A,b_ub=b,bounds=list(zip(lo,hi)),method="highs")
            if not res.success or -res.fun<self.target-1e-8 or not self.find_cut(res.x):
                break
        return res

    def run(self,limit,report):
        dim=len(self.pairs)
        stack=[(np.zeros(dim),np.ones(dim),0)]
        timer=monotonic()
        for processed in range(limit):
            if not stack:
                break
            lo,hi,depth=stack.pop()
            res=self.relax(lo,hi)
            if not res.success or -res.fun<self.target-1e-8:
                self.counts["empty"]+=1
            elif -res.fun<=self.target+1e-9:
                self.counts["closed"]+=1
            elif depth>=90:
                self.counts["unresolved"]+=1
                print("Near-target unresolved",depth,-res.fun,flush=True)
                break
            else:
                x=res.x
                gap=(hi-x)*(x-lo)
                axis=int(np.argmax(gap+.02*(hi-lo)))
                mid=(hi[axis]+lo[axis])/2
                hl,lr=hi.copy(),lo.copy()
                hl[axis]=lr[axis]=mid
                stack.extend([(lr,hi,depth+1),(lo,hl,depth+1)])
                self.counts["split"]+=1
            if processed%report==0:
                print(processed, self.counts, "open",len(stack),"depth",depth,
                      "upper",None if not res.success else -res.fun,
                      "secs",round(monotonic()-timer,2),flush=True)
        print("Final",self.counts,"open",len(stack),flush=True)

if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--n",default=7,type=int)
    p.add_argument("--limit",default=1000,type=int)
    p.add_argument("--report",default=100,type=int)
    args=p.parse_args()
    Search(args.n).run(args.limit,args.report)
