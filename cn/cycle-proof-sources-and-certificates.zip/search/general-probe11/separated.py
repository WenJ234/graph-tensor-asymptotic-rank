"""Explore longer orders using sparse separation of boxwise Ptolemy constraints."""
from argparse import ArgumentParser
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csr_matrix, vstack
from probe9 import WalkSearch


class Separated(WalkSearch):
    def __init__(self,n):
        super().__init__(n,True,False,True,True,True)
        # Conditional on each smaller odd-cycle metric theorem.
        self.caps.extend((r,r-1+1/(4*(r-2))) for r in range(11,n,2))
        self.last_used=set()

    def relax(self,lo,hi):
        q=self.quads
        # q_all has six coordinate indices per row. The next arrays have at
        # most six nonzeros per row; materializing a dense full LP is costly.
        indices=[]
        weights=[]
        offsets=[]
        for b in self.pts:
            v=np.array([(lo,hi)[bit][q[:,p]] for p,bit in enumerate(b)])
            indices.append(q)
            weights.append(np.array([v[1],v[0],-v[3],-v[2],-v[5],-v[4]]).T)
            offsets.append(v[0]*v[1]-v[2]*v[3]-v[4]*v[5])
        x,y,u,v,w,z=q.T
        cross=np.maximum.reduce([lo[u],lo[v],lo[w],lo[z],np.full(len(x),1e-12)])
        for a,b,s,t in [(x,y,lo[u]+lo[z],lo[w]+lo[v]),(y,x,lo[u]+lo[w],lo[z]+lo[v])]:
            K=np.minimum.reduce([np.full(len(x),2.), 2*hi[b]/cross,
               np.maximum(1.,2*hi[b]/np.maximum(1e-12,np.minimum(s,t)))])
            ind=np.stack([a,u,v,w,z,b],axis=1)
            ones=np.ones_like(K)
            for sign in (-1,1):
                signs=sign*ones
                indices.append(ind)
                weights.append(np.stack([-K,signs,signs,-signs,-signs,0*ones],axis=1))
                offsets.append(0*ones)
        idx=np.vstack(indices)
        values=np.vstack(weights)
        offsets=np.concatenate(offsets)
        rows=np.repeat(np.arange(len(idx)),6)
        constraints=csr_matrix((values.ravel(),(rows,idx.ravel())),shape=(len(idx),len(lo)))
        select=set(self.last_used)
        for it in range(18):
            selected=np.array(sorted(select),dtype=int)
            A=csr_matrix(self.rows)
            all_rows=vstack([A,constraints[selected]],format="csr")
            rhs=np.concatenate([self.rhs,offsets[selected]])
            labels=[]
            nq=len(q)
            for row_id in selected:
                group,position=divmod(int(row_id),nq)
                a,b,c,d,e,f=map(int,q[position])
                if group<8:
                    ends=self.pts[group]
                    labels.append(("p",a,b,c,d,e,f,ends[0],ends[2],ends[4]))
                else:
                    sign=1 if group%2 else -1
                    orient=(a,b,c,d,e,f) if group<10 else (b,a,c,d,f,e)
                    labels.append(("mix",*orient,sign))
            self.last_lp=all_rows,rhs,self.labels+labels
            res=linprog(self.obj,A_ub=all_rows,b_ub=rhs,bounds=list(zip(lo,hi)),method="highs")
            if not res.success:
                break
            if -res.fun < self.target-1.e-8:
                break
            residual=constraints@res.x-offsets
            if len(selected):
                residual[selected]=0.
            pool=np.flatnonzero(residual>5.e-8)
            more=self.find_cut(res.x)
            if len(pool)>96:
                pp=np.argpartition(residual[pool],-96)[-96:]
                pool=pool[pp]
            if not len(pool) and not more:
                break
            select.update(map(int,pool))
        if res.success and len(selected):
            self.last_used={int(j) for j,d in zip(selected,res.ineqlin.marginals[-len(selected):]) if d < -1e-9}
        return res

if __name__=="__main__":
    p=ArgumentParser()
    p.add_argument("n",type=int)
    p.add_argument("--limit",type=int,default=1200)
    p.add_argument("--report",type=int,default=25)
    a=p.parse_args()
    Separated(a.n).run_regions(a.limit,a.report)
