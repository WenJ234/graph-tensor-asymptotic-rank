"""Generate an exact dyadic-box certificate for C9, conditionally on C7."""

import argparse
from collections import Counter
from fractions import Fraction as Q
from functools import lru_cache
from itertools import combinations
import json
from math import isqrt, lcm
from pathlib import Path
import sys
from time import monotonic

import numpy as np
from scipy.sparse import csr_matrix

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from general_cert import Rules, check
from produce_long_cert import Producer
from probe9 import WalkSearch


class C9Rules(Rules):
    @lru_cache(None)
    def local(self, c):
        n, k, x, K = self.n, self.n//2, self.n-2, Q(4,3)
        a = [(c+1+2*j)%n for j in range(k)]
        b = [(c+2+2*j)%n for j in range(k)]
        pa = [(self.ix(a[0],v),1) for v in a[1:]]
        pb = [(self.ix(b[-1],v),1) for v in b[:-1]]
        A,B,R = [(self.ix(c,a[0]),1)],[(self.ix(c,b[-1]),1)],[(self.ix(a[0],b[-1]),1)]
        def mix(*terms):
            result = Counter()
            for fac, row in terms:
                for i,w in row:
                    result[i] += fac*w
            return tuple((i,w) for i,w in result.items() if w)
        d = Q(x,k)
        z = d-K
        return pa,pb,(
            mix((2,B),(2,pb),(-2*K,A),(K,pa)),mix((2,A),(2,pa),(-2*K,B),(K,pb)),
            mix((2,B),(2+2*K,pb),(-2*K,R),(K,pa)),mix((2,A),(2+2*K,pa),(-2*K,R),(K,pb)),
            mix((d+z,pb),(z,pa),(-z,R)), mix((d+z,pa),(z,pb),(-z,R)))

    @lru_cache(None)
    def static(self, rule):
        op, *a = rule
        n = self.n
        if op == "obj":
            return [(i, -1) for i in self.edges], -self.target
        if op == "tripod-radius":
            c, = a
            check(0<=c<n, "invalid center")
            pa, pb, _ = self.local(c)
            return [(i,-w) for i,w in pa+pb], -Q(1,512*(n-2))
        if op == "reg":
            c,j,sign = a
            check(0<=c<n and 0<=j<6 and sign in (-1,1), "invalid local assumption")
            _,_,regions = self.local(c)
            return [(i,sign*w) for i,w in regions[j]], 0
        if op == "longest-floor":
            return [(self.edges[0], -1)], -self.target/n
        if op == "longest-bound":
            i, = a
            check(1 <= i < n, "longest-edge index")
            return [(self.edges[0], 1-n), (self.edges[i], -1)], -self.target
        if op == "walk":
            q, *tour = a
            check(q in range(5,n+1,2) and len(tour) == q and all(0<=v<n for v in tour), "tour")
            walk = [(self.ix(tour[i-1], v), 1) for i, v in enumerate(tour) if tour[i-1]!=v]
            if q < n:
                return walk, Q(q-1)+Q(1,4*(q-2))
            return walk + [(i,-1) for i in self.edges], 0
        if op == "replace":
            i,j,k,h = a
            check(i == (j-1)%n and k == (j+1)%n and len(set(a))==4, "replacement")
            return [(self.ix(u,v), s) for u,v,s in [(i,h,1),(h,k,1),(i,j,-1),(j,k,-1)]],0
        if op == "two-opt":
            i,j,k,h = a
            check(j == (i+1)%n and h == (k+1)%n and len(set(a))==4, "two-opt")
            return [(self.ix(u,v), s) for u,v,s in [(i,k,1),(j,h,1),(i,j,-1),(k,h,-1)]],0
        return super().static(rule)


class Generate9(WalkSearch):
    register = Producer.register
    prove = Producer.prove

    def __init__(self, grid, subsets=False, regions=False, n=9, strong=False):
        super().__init__(n, seven=True, shortest=False, heaviest=True, tripod=regions, sharpen=True)
        self.caps.extend((q,q-1+1/(4*(q-2))) for q in range(9,n,2))
        self.rulebook = C9Rules(n)
        self.strong = strong
        self.ids, self.dictionary = {}, []
        self.count = Counter()
        self.start = monotonic()
        self.grid = grid
        self.rec_tri = np.asarray([(self.ix(i,k),self.ix(i,j),self.ix(j,k))
                                  for i in range(n) for k in range(i) for j in range(n) if j not in (i,k)]).T
        self.subweights = []
        if subsets:
            k, x = n//2, n-2
            for c in range(n):
                a = [(c+1+2*j)%n for j in range(k)]
                b = [(c+2+2*j)%n for j in range(k)]
                for na in range(1,k+1):
                    for nb in range(1,k+1):
                        for sa in combinations(a,na):
                            for sb in combinations(b,nb):
                                scale = lcm(na,nb)
                                self.subweights.append(tuple(scale if i==c else
                                    (x*scale//na if i in sa else x*scale//nb if i in sb else 0) for i in range(n)))
            self.submatrix = np.array([[4*w[i]*w[j]/sum(w)**2 for i,j in self.pairs] for w in self.subweights])

    def find_cut(self, x):
        added = False
        if self.subweights:
            vals = self.submatrix @ x
            for i in np.argpartition(vals,-12)[-12:]:
                w = self.subweights[i]
                if vals[i] > 1+1e-8 and w not in self.known:
                    self.cp(w)
                    added = True
        return super().find_cut(x) or added

    @lru_cache(None)
    def integer_row(self, rule):
        coeffs, rhs = self.rulebook.static(rule)
        best = Counter()
        for j, c in coeffs:
            best[j] += Q(c)
        den = lcm(Q(rhs).denominator, *(Q(c).denominator for c in best.values()))
        return {j:int(c*den) for j,c in best.items() if c}, int(rhs*den)

    def tighten_exact(self, low, high):
        lo, hi, S = low.copy(), high.copy(), self.grid
        A = csr_matrix(np.vstack([self.rows,self.obj]))
        keep = np.diff(A.indptr) > 0
        A = A[keep]
        labels = [r for r, ok in zip(self.labels+[("obj",)], keep) if ok]
        rhs = np.append(self.rhs,-self.target)[keep]
        idx, vals = A.indices, A.data
        row = np.repeat(np.arange(A.shape[0]),np.diff(A.indptr))
        pos = vals>0
        rid, qid, sid = self.rec_tri
        updates = []

        def commit(op, coord, cand, *reason):
            if op == "l":
                cand = min(S+1, int(cand))
                if cand <= lo[coord]:
                    return
                lo[coord] = cand
            else:
                cand = max(-1, int(cand))
                if cand >= hi[coord]:
                    return
                hi[coord] = cand
            if op in ("g","g2"):
                updates.append([op, int(coord), *reason, int(cand)])
            else:
                updates.append([op, int(coord), int(cand), *reason])

        for rnd in range(12):
            if np.any(lo>hi):
                break
            old = len(updates)
            endpoint = np.where(pos,lo[idx],hi[idx])
            margin = S*rhs - np.add.reduceat(vals*endpoint,A.indptr[:-1])
            bound = endpoint+margin[row]/vals
            def choose(mask, low_bound):
                locs = np.flatnonzero(mask)
                # Choose one most effective row per variable in this sweep.
                order = np.lexsort(((-1 if low_bound else 1)*bound[locs],idx[locs]))
                ordered = locs[order]
                return ordered[np.r_[True, idx[ordered][1:]!=idx[ordered][:-1]]] if len(ordered) else []
            preferred = [(int(e),"u") for e in choose(pos & (bound<hi[idx]-0.99),False)]
            preferred += [(int(e),"l") for e in choose(~pos & (bound>lo[idx]+0.99),True)]
            for e, op in preferred:
                axis = int(idx[e])
                rule = tuple(labels[row[e]])
                co, b = self.integer_row(rule)
                v = co[axis]
                base = b*S-sum(c*int(lo[j] if c>0 else hi[j]) for j,c in co.items() if j!=axis)
                new = -(-base//v) if op == "u" else base//v
                commit(op,axis,new,self.register(rule))
                if lo[axis]>hi[axis]:
                    return lo,hi,updates
            caps = (np.sqrt(np.maximum(0,S-lo[qid]))+np.sqrt(np.maximum(0,S-lo[sid])))**2
            if self.strong:
                ux,uy = lo[qid]/S,lo[sid]/S
                improved = S*(np.sqrt(ux*(1-uy))+np.sqrt(uy*(1-ux)))**2
                caps = np.minimum(caps,np.where(ux+uy>1,improved,S))
            good = np.flatnonzero(caps<hi[rid]-0.99)
            if len(good):
                order = good[np.lexsort((caps[good],rid[good]))]
                picks = order[np.r_[True,rid[order][1:]!=rid[order][:-1]]]
                for m in picks:
                    z, i, j = int(rid[m]), int(qid[m]), int(sid[m])
                    a,b = S-int(lo[i]), S-int(lo[j])
                    t = isqrt(4*a*b)
                    cap = a+b+t+int(t*t<4*a*b)
                    op = "g"
                    if self.strong and a+b<S:
                        x,y = S-a,S-b
                        prod = 4*x*y*a*b
                        root = isqrt(prod)
                        top = x*b+y*a+root+int(root*root<prod)
                        refined = -(-top//S)
                        if refined < cap:
                            cap, op = refined, "g2"
                    commit(op,z,cap,i,j)
                    if lo[z]>hi[z]:
                        return lo,hi,updates
            if len(updates)==old:
                break
        return lo,hi,updates

    def visit(self, low, high, depth, used=frozenset()):
        self.count["nodes"]+=1
        lo, hi, updates = self.tighten_exact(low,high)
        self.count["updates"]+=len(updates)
        if np.any(lo>hi):
            self.count["x"]+=1
            return [updates,["x"]]
        flo, fhi = lo/self.grid, hi/self.grid
        res = self.relax(flo,fhi)
        if not res.success or -res.fun<=self.target+1e-8:
            cert = self.prove(flo,fhi,res)
            if cert:
                self.count[cert[0]]+=1
                return [updates,cert]
            self.count["retry"]+=1
            if not res.success:
                raise RuntimeError(("no exact Farkas proof",depth))
        fits = [((region@res.x).max(),c) for c,region in enumerate(self.tripod_regions) if c not in used]
        worst, center = min(fits,default=(1,-1))
        if worst < -1e-7:
            self.count["region"]+=1
            region = self.tripod_regions[center]
            children = []
            for j in range(6):
                first = len(self.rows)
                for i in range(j+1):
                    sign = 1 if i<j else -1
                    self.add(sign*region[i],0,("reg",center,i,sign))
                children.append(self.visit(lo,hi,depth+1,used|{center}))
                for series in (self.rows,self.rhs,self.labels):
                    del series[first:first+j+1]
            return [updates,["r",center,*children]]
        if depth>=100:
            raise RuntimeError(("unresolved",depth,res.fun))
        gap = (fhi-res.x)*(res.x-flo)+.02*(fhi-flo)
        gap[hi-lo<=1]=-1
        axis=int(np.argmax(gap))
        if gap[axis]<0:
            raise RuntimeError("grid exhausted")
        mid=int((lo[axis]+hi[axis])//2)
        lh,rl=hi.copy(),lo.copy()
        lh[axis]=rl[axis]=mid
        self.count["split"]+=1
        if self.count["nodes"]%30<2:
            print(dict(self.count), "depth",depth,"sec",round(monotonic()-self.start,2),flush=True)
        return [updates,["s",axis,mid,self.visit(lo,lh,depth+1,used),self.visit(rl,hi,depth+1,used)]]

    def export(self):
        dim = len(self.pairs)
        tree = self.visit(np.zeros(dim,dtype=int),np.full(dim,self.grid,dtype=int),0)
        return dict(n=self.n,grid=self.grid,rules=self.dictionary,tree=tree)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("output",type=Path)
    parser.add_argument("--grid-bits",type=int,default=20)
    parser.add_argument("--subsets",action="store_true")
    parser.add_argument("--regions",action="store_true")
    parser.add_argument("--n",type=int,default=9)
    parser.add_argument("--strong",action="store_true")
    args = parser.parse_args()
    search = Generate9(2**args.grid_bits,args.subsets,args.regions,args.n,args.strong)
    document = search.export()
    args.output.write_text(json.dumps(document,separators=(",",":")),encoding="ascii")
    print(dict(search.count),"rules",len(search.dictionary),flush=True)
