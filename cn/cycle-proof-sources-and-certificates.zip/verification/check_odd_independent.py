"""Replay an odd-cycle certificate using standard-library rational arithmetic.

Usage: python check_odd_independent.py path/to/certificate.json[.gz]
Inputs to the proof are the copositivity and CAT(0) spectral constraints,
the triangle and Ptolemy inequalities, and the C5 perimeter theorem (49/12).
"""
import argparse
from collections import Counter
from fractions import Fraction
import gzip
from itertools import combinations, permutations
import json
from pathlib import Path


class Invalid(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise Invalid(message)


def integer(number):
    return type(number) is int


def index(number, size):
    require(integer(number) and 0 <= number < size, f"invalid index {number!r}")
    return number


def local_rows(n, c, edge):
    """Six sufficient inequalities for the alternating three-cluster lemma."""
    k = n // 2
    a = [(c+1+2*i) % n for i in range(k)]
    b = [(c+2+2*i) % n for i in range(k)]
    # Ordered features: d(C,A1), d(C,Bk), d(A1,Bk), PA, PB.
    features = [[edge(c, a[0])], [edge(c, b[-1])], [edge(a[0], b[-1])],
                [edge(a[0], v) for v in a[1:]], [edge(b[-1], v) for v in b[:-1]]]
    K, q = Fraction(4, 3), Fraction(n-2, k)
    delta = q - K
    coefficients = [(-2*K, 2, 0, K, 2), (2, -2*K, 0, 2, K),
                    (0, 2, -2*K, K, 2+2*K), (2, 0, -2*K, 2+2*K, K),
                    (0, 0, -delta, delta, delta+q), (0, 0, -delta, delta+q, delta)]
    return [tuple((e, v) for v, group in zip(weights, features) if v for e in group)
            for weights in coefficients]


def parse(document, grid_mode=False):
    expected = {"n", "rules", "tree"} | ({"grid"} if grid_mode else set())
    require(type(document) is dict and set(document) == expected, "invalid document fields")
    n = document["n"]
    require(integer(n) and n >= 5 and n % 2 == 1, "expected an odd order >= 5")
    pairs = list(combinations(range(n), 2))
    pair_index = {p: i for i, p in enumerate(pairs)}
    dimensions = len(pairs)

    def edge(a, b):
        return pair_index[tuple(sorted((a, b)))]

    cycle = {edge(v, (v + 1) % n) for v in range(n)}
    target = n - 1 + Fraction(1, 4 * (n - 2))
    oriented = set()
    for a, b, c, d in permutations(range(n), 4):
        oriented.add((edge(a, b), edge(c, d), edge(a, c), edge(b, d),
                      edge(a, d), edge(b, c)))

    rules = document["rules"]
    require(type(rules) is list, "expected a list of rules")
    # Normalize and validate every rule up front, including unused rules.
    static = {}
    variable = {}
    for j, rule in enumerate(rules):
        require(type(rule) is list and rule and type(rule[0]) is str
                and all(integer(v) for v in rule[1:]), f"bad rule {j}")
        kind = rule[0]
        args = tuple(rule[1:])
        if kind == "t":
            require(len(args) == len(set(args)) == 3, "bad triangle")
            i, v, h = (index(i, n) for i in args)
            static[j] = (0, ((edge(i, h), 1), (edge(i, v), -1), (edge(v, h), -1)))
        elif kind == "sym":
            require(len(args) == 2 and (args[0] in cycle - {edge(0, 1)} and args[1] == edge(0, 1)
                    or args == (edge(1, 2), edge(0, n - 1))), "bad symmetry choice")
            static[j] = (0, ((args[0], 1), (args[1], -1)))
        elif kind == "cp":
            require(len(args) == n and min(args) >= 0 and sum(args) > 0,
                    "invalid weight vector")
            squared_mass = sum(args) ** 2
            static[j] = (1, tuple((e, Fraction(4 * args[a] * args[b], squared_mass))
                                  for e, (a, b) in enumerate(pairs) if args[a] * args[b]))
        elif kind == "c5":
            require(len(args) == len(set(args)) == 5, "expected five distinct sites")
            for i in args:
                index(i, n)
            static[j] = (Fraction(49, 12), tuple((edge(args[i - 1], args[i]), 1)
                                                for i in range(5)))
        elif grid_mode and kind in ("obj", "longest-floor", "longest-bound"):
            if kind == "longest-bound":
                require(len(args) == 1 and 1 <= args[0] < n, "invalid longest bound")
                t = args[0]
                static[j] = (-target, ((edge(0, 1), 1-n), (edge(t, (t+1) % n), -1)))
            else:
                require(not args, "rule should have no index")
                static[j] = ((-target, tuple((e, -1) for e in cycle)) if kind == "obj"
                             else (-target/n, ((edge(0, 1), -1),)))
        elif grid_mode and kind == "walk":
            require(args and len(args) == 1 + args[0] and 5<=args[0]<=n and args[0]%2==1,
                    "invalid odd walk length")
            length, *sites = args
            for v in sites:
                index(v, n)
            entries = [(edge(v, sites[i-1]), 1) for i, v in enumerate(sites)
                       if v != sites[i-1]]
            if length == n:
                entries.extend((e, -1) for e in cycle)
                cap = 0
            else:
                require(n > length, "walk cap must use a smaller theorem")
                cap = length - 1 + Fraction(1, 4 * (length - 2))
            static[j] = (cap, tuple(entries))
        elif grid_mode and kind in ("replace", "two-opt"):
            require(len(args) == 4, "four sites expected")
            a, b, c, d = (index(t, n) for t in args)
            if kind == "two-opt":
                require(len(set(args)) == 4 and b == (a+1) % n and d == (c+1) % n,
                        "invalid two-opt edges")
                static[j] = (0, ((edge(a, c), 1), (edge(b, d), 1),
                                 (edge(a, b), -1), (edge(c, d), -1)))
            else:
                require(a == (b-1) % n and c == (b+1) % n and d not in (a,b,c),
                        "invalid single-vertex replacement")
                static[j] = (0, ((edge(a, d), 1), (edge(d, c), 1),
                                 (edge(a, b), -1), (edge(b, c), -1)))
        elif grid_mode and kind == "reg":
            require(len(args)==3 and args[2] in (-1,1), "bad local-region rule")
            c, part, sign = args
            entries = local_rows(n, index(c,n), edge)[index(part,6)]
            static[j] = (0, tuple((e,sign*v) for e,v in entries))
        elif grid_mode and kind == "tripod-radius":
            require(len(args) == 1, "one center is required for the exclusion radius")
            c = index(args[0], n)
            k = n // 2
            a = [(c+1+2*i) % n for i in range(k)]
            b = [(c+2+2*i) % n for i in range(k)]
            static[j] = (-Fraction(1, 512*(n-2)), tuple(
                [(edge(a[0], v), -1) for v in a[1:]]
                + [(edge(b[-1], v), -1) for v in b[:-1]]))
        elif kind in ("ub", "lb"):
            require(len(args) == 1, f"bad box rule {j}")
            variable[j] = (kind, (index(args[0], dimensions),))
        elif kind == "mix":
            require(len(args) == 7 and args[:6] in oriented and args[6] in (-1, 1),
                    f"bad oriented matching or sign in rule {j}")
            variable[j] = (kind, args)
        elif kind == "p":
            require(len(args) == 9 and all(t in (0, 1) for t in args[6:]),
                    f"invalid product support {j}")
            # Product order is arbitrary in Ptolemy, including swapping the
            # two factors. All 6 edges must form the 3 complementary matchings.
            x, y, u, v, w, z = (index(i, dimensions) for i in args[:6])
            four = set(pairs[x] + pairs[y])
            require(len(four) == 4 and len({x, y, u, v, w, z}) == 6 and
                    set(pairs[u] + pairs[v]) == four == set(pairs[w] + pairs[z]),
                    f"bad Ptolemy matching {j}")
            variable[j] = (kind, args)
        else:
            raise Invalid(f"unknown rule {kind!r}")

    def row(j, lo, hi):
        if j in static:
            return static[j]
        kind, args = variable[j]
        if kind == "ub":
            return hi[args[0]], ((args[0], 1),)
        if kind == "lb":
            return -lo[args[0]], ((args[0], -1),)
        x, y, u, v, w, z = args[:6]
        if kind == "mix":
            sign = args[6]
            coefficient = 2
            numerator = 2 * hi[y]
            largest = max(lo[u], lo[v], lo[w], lo[z])
            smallest_sum = min(lo[u] + lo[z], lo[v] + lo[w])
            if largest:
                coefficient = min(coefficient, numerator / largest)
            if smallest_sum:
                coefficient = min(coefficient, max(1, numerator / smallest_sum))
            return 0, ((x, -coefficient), (u, sign), (v, sign), (w, -sign), (z, -sign))
        endpoints = (lo, hi)
        entries = []
        rhs = 0
        for a, b, bit, sign in ((x, y, args[6], 1), (u, v, args[7], -1),
                                (w, z, args[8], -1)):
            pa = endpoints[bit][a]
            pb = endpoints[bit if sign == 1 else 1-bit][b]
            # (a-pa)(b-pb) >=0 at like endpoints and <=0 at unlike endpoints.
            entries.extend(((a, sign * pb), (b, sign * pa)))
            rhs += sign * pa * pb
        return rhs, entries

    return n, dimensions, cycle, len(rules), row


def verify(document):
    if type(document) is dict and "grid" in document:
        return verify_grid(document)
    n, dimensions, cycle, number_of_rules, row = parse(document)
    target = n - 1 + Fraction(1, 4 * (n - 2))
    zero, one = Fraction(0), Fraction(1)
    stack = [(document["tree"], [zero] * dimensions, [one] * dimensions, 0)]
    counts = Counter()
    max_depth = 0
    while stack:
        node, lo, hi, depth = stack.pop()
        max_depth = max(depth, max_depth)
        require(type(node) is list and node and type(node[0]) is str, "bad node")
        kind = node[0]
        counts[kind] += 1
        if kind == "s":
            require(len(node) == 4, "a split requires both subtrees")
            axis = index(node[1], dimensions)
            mid = (lo[axis] + hi[axis]) / 2
            left_hi, right_lo = hi.copy(), lo.copy()
            left_hi[axis] = right_lo[axis] = mid
            stack.extend(((node[3], right_lo, hi, depth + 1),
                          (node[2], lo, left_hi, depth + 1)))
            continue
        require(kind in ("b", "e") and len(node) == 2 and type(node[1]) is list,
                f"bad leaf at depth {depth}")
        residual = [int(kind == "b" and e in cycle) for e in range(dimensions)]
        constant = 0
        for term in node[1]:
            require(type(term) is list and len(term) == 3
                    and all(integer(i) for i in term), "invalid multiplier")
            j, a, b = term
            index(j, number_of_rules)
            require(a >= 0 and b > 0, "invalid multiplier sign or denominator")
            weight = Fraction(a, b)
            rhs, entries = row(j, lo, hi)
            constant += weight * rhs
            for e, v in entries:
                residual[e] -= weight * v
        upper = constant + sum(c * (hi[j] if c > 0 else lo[j])
                               for j, c in enumerate(residual))
        require(upper <= target if kind == "b" else upper < 0,
                f"leaf {sum(counts.values())} at depth {depth} fails with {upper}")
    require(counts["s"] + 1 == counts["e"] + counts["b"], "incomplete tree")
    return {"n": n, "upper": str(target), "splits": counts["s"],
            "bounds": counts["b"], "empty": counts["e"], "max_depth": max_depth}


def verify_grid(document):
    """Exclude D>G after maximizing the closed walk.

    Repetitions are allowed in the maximizing walk. Relabeling its sites, with
    multiplicity, preserves the constraints. Rotations and reflections then
    make edge 01 longest and its left neighboring edge at least its right one.
    """
    n, dimensions, cycle, number_of_rules, row = parse(document, True)
    size = document["grid"]
    require(integer(size) and size > 0, "invalid grid")
    target = n - 1 + Fraction(1, 4 * (n - 2))
    triangles = set()
    pairs = list(combinations(range(n), 2))
    ids = {pair: e for e, pair in enumerate(pairs)}
    for i, j, k in combinations(range(n), 3):
        triangles.add(frozenset([ids[i,j], ids[j,k], ids[i,k]]))
    counts = Counter()
    regional = {j: tuple(rule[1:]) for j,rule in enumerate(document["rules"]) if rule[0]=="reg"}
    def edge(a, b):
        return ids[tuple(sorted((a, b)))]
    stack = [(document["tree"], [Fraction(0)]*dimensions, [Fraction(1)]*dimensions, 0, frozenset())]
    max_depth = 0
    while stack:
        node, lo, hi, depth, active = stack.pop()
        max_depth = max(depth, max_depth)
        require(type(node) is list and len(node) == 2 and type(node[0]) is list
                and type(node[1]) is list and node[1], "bad grid node")
        for update in node[0]:
            require(type(update) is list and len(update) >= 4
                    and all(integer(t) for t in update[1:]), "malformed bound update")
            op = update[0]
            counts["updates"] += 1
            if op in ("g","g2"):
                require(len(update) == 5, "invalid lens update")
                _, dest, q, s, tick = update
                require(frozenset((dest,q,s)) in triangles and len({dest,q,s}) == 3,
                        "lens coordinates must form a triangle")
                bound = Fraction(tick, size)
                # Testing copositivity with masses (x,x+z,z) implies
                # d_dest <= (sqrt(1-d_q)+sqrt(1-d_s))**2.
                x,y = lo[q],lo[s]
                if op == "g":
                    excess = bound-2+x+y
                    radicand = 4*(1-x)*(1-y)
                else:
                    require(x+y>1, "strong lens requires opposing long edges")
                    excess = bound-x*(1-y)-y*(1-x)
                    radicand = 4*x*y*(1-x)*(1-y)
                require(excess >= 0 and excess**2 >= radicand and bound <= hi[dest],
                        "unproved lens bound")
                hi[dest] = bound
                continue
            require(op in ("l", "u") and len(update) == 4, "invalid propagation rule")
            _, dest, tick, j = update
            index(dest, dimensions)
            index(j, number_of_rules)
            require(j not in regional or regional[j] in active, "unavailable local hypothesis")
            bound = Fraction(tick, size)
            rhs, entries = row(j, lo, hi)
            coefficients = Counter()
            for e, v in entries:
                coefficients[e] += v
            c = coefficients.pop(dest, 0)
            margin = rhs - sum(v * (lo[e] if v > 0 else hi[e])
                               for e, v in coefficients.items())
            require(margin <= c*bound, "linear implication fails")
            if op == "l":
                require(c < 0 and bound >= lo[dest], "invalid lower-bound update")
                lo[dest] = bound
            else:
                require(c > 0 and bound <= hi[dest], "invalid upper-bound update")
                hi[dest] = bound
        action = node[1]
        kind = action[0]
        require(type(kind) is str, "invalid action")
        counts[kind] += 1
        if kind == "x":
            require(len(action) == 1 and any(a>b for a,b in zip(lo,hi)),
                    "claimed coordinate contradiction is absent")
            continue
        require(all(a<=b for a,b in zip(lo,hi)), "empty box requires an exclusion leaf")
        if kind == "s":
            require(len(action) == 5 and integer(action[2]), "invalid grid split")
            _, dest, tick, left, right = action
            index(dest, dimensions)
            point = Fraction(tick, size)
            require(lo[dest] < point < hi[dest], "split is exterior to the box")
            lh, rl = hi.copy(), lo.copy()
            lh[dest] = rl[dest] = point
            stack.extend(((right, rl, hi.copy(), depth+1, active),
                          (left, lo.copy(), lh, depth+1, active)))
            continue
        if kind in ("r","z"):
            require(len(action)==(8 if kind=="r" else 2), "invalid local region")
            c = index(action[1],n)
            if kind == "z":
                for entries in local_rows(n,c,edge):
                    require(sum(v*(hi[e] if v>0 else lo[e]) for e,v in entries)<=0,
                            "local row does not hold on this box")
            else:
                # The case in which all six rows hold is closed analytically.
                # Otherwise pick the first row that fails. Its non-strict
                # opposite suffices, since overlaps on the boundary are harmless.
                prefix = set(active)
                for i,child in enumerate(action[2:]):
                    subcase = frozenset(prefix | {(c,i,-1)})
                    stack.append((child,lo.copy(),hi.copy(),depth+1,subcase))
                    prefix.add((c,i,1))
            continue
        require(kind in ("e","b") and len(action)==2 and type(action[1]) is list,
                "invalid grid terminal action")
        coef = Counter({e: 1 for e in cycle} if kind == "b" else {})
        scalar = 0
        for term in action[1]:
            require(type(term) is list and len(term) == 3 and all(integer(t) for t in term),
                    "malformed multiplier")
            j, a, b = term
            index(j, number_of_rules)
            require(j not in regional or regional[j] in active, "unavailable local hypothesis")
            require(a >= 0 and b > 0, "invalid multiplier")
            multiplier = Fraction(a, b)
            rhs, entries = row(j, lo, hi)
            scalar += rhs * multiplier
            for e, coefficient in entries:
                coef[e] -= coefficient * multiplier
        upper = scalar + sum(v*(hi[e] if v>0 else lo[e]) for e,v in coef.items())
        require(upper<=target if kind=="b" else upper<0, f"unproved terminal bound {upper}")
    require(counts["s"]+5*counts["r"]+1 == counts["b"]+counts["x"]+counts["e"]+counts["z"],
            "incomplete tree")
    return {"n": n, "upper": str(target), "splits": counts["s"], "bounds": counts["b"],
            "empty": counts["e"], "crossed_bounds": counts["x"],
            "updates": counts["updates"], "max_depth": max_depth,
            "local_splits": counts["r"], "local_leaves": counts["z"]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("certificate", type=Path)
    path = parser.parse_args().certificate
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as file:
        print(json.dumps(verify(json.load(file))))
