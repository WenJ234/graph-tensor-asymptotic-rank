"""Exact coefficient checks for regrouping and the alternating flattening."""
from collections import Counter
from fractions import Fraction
from itertools import product


def rectangular_grouping(n):
    # The edge from i to i+1 carries bits[i]; the last site is C.
    party = [i % 2 for i in range(n - 1)] + [2]
    edge_types = [tuple(sorted((party[i],party[(i+1)%n]))) for i in range(n)]
    assert Counter(edge_types)=={(0,1):n-2,(1,2):1,(0,2):1}
    observed=set()
    for labels in product(range(2),repeat=n):
        grouped=[{} for _ in range(3)]
        for i,p in enumerate(party):
            for e in ((i-1)%n,i):
                assert e not in grouped[p]
                grouped[p][e]=labels[e]
        z=tuple(tuple((e,si[e]) for e in sorted(si)) for si in grouped)
        observed.add(z)
    wires={pair:[i for i,p in enumerate(edge_types) if p==pair]
           for pair in ((0,1),(0,2),(1,2))}
    expected=set()
    for ab in product(range(2),repeat=n-2):
        for ac,bc in product(range(2),repeat=2):
            values=dict(zip(wires[0,1],ab))
            values.update({wires[0,2][0]:ac,wires[1,2][0]:bc})
            expected.add(tuple(tuple((i,values[i]) for i,t in enumerate(edge_types) if p in t)
                               for p in range(3)))
    assert observed==expected and len(expected)==2**n
    print(f"C{n}: every nonzero grouped coefficient agrees with <{2**(n-2)},2,2>.")


def alternating_flattening(n):
    rows=set()
    cols=set()
    for labels in product(range(2), repeat=n):
        local=[(labels[i-1],labels[i]) for i in range(n)]
        row, col=tuple(local[::2]),tuple(local[1::2])
        assert row not in rows and col not in cols
        rows.add(row)
        cols.add(col)
    assert len(rows)==len(cols)==2**n
    print(f"C{n}: alternating flattening is a permutation matrix of size {2**n}.")


if __name__=="__main__":
    for n in (4,6,8):
        alternating_flattening(n)
    for n in (3,5,7,9):
        rectangular_grouping(n)
        h=n-2
        assert Fraction((2*h+1)**2,4*h)==n-1+Fraction(1,4*h)
