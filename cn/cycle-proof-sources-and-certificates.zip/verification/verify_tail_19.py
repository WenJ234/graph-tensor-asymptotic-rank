"""Verify the perimeter bound for every odd m >= 19.

Run with --export FILE to save the cover, or --replay FILE to verify a saved cover.
All bounds, branch choices, and verifications use exact rational or integer arithmetic.
"""
from argparse import ArgumentParser
from collections import Counter
from fractions import Fraction
from math import isqrt
from pathlib import Path
import json


def certify(replay=None):
    M=19
    N=Fraction
    zero,one=N(0),N(1)
    half=one/2
    cap=2-one/((M-1)//2)
    zs=[one/j for j in range(1,9)]+[one*2/3,one*3/2,one*2]
    def ec(t):return (2-t)*(1+t)/(2*(1-t))
    def sqrt_up(t):
        scale=10000000
        return Fraction(isqrt(t.numerator*scale*scale//t.denominator)+1,scale)
    if M<13:raise ValueError("unique-seam starting condition not met")
    R=min(one*2/7,sqrt_up(one/M))
    for _ in range(3):
        R=min(R,3*ec(R)/(M-1))
        R=Fraction((R*10**7).__ceil__(),10**7)
    def kernel(r0,r1,u0,u1,v0,v1):
        if u1<v0:return "empty"
        v1=min(v1,u1);u0=max(u0,v0)
        d=1-r1*r1
        eta=(r1+r1*r1)/2
        E=r1*ec(r1)
        B=(r0+r0*r0 if 2*(M-2)*r0<=1
           else (M-1)*r0*r0+one/(4*(M-2)))
        fixed=2*d*u0*v0+B
        if 3*E<fixed:return "empty"
        # Each ordinary A vertex has both cross edges available. The
        # neighbors X',Y' on the B side have one extra cross edge available
        # and its coefficient is at least 2(1-u).
        wa=(5*E-fixed)/2
        wb=max(wa,(4*E-fixed)/(2*(1-u1)))
        def lens(w):
            w=min(half,w)
            return min(w,(r1*r1+r1*sqrt_up(1-d*(1-2*w)**2))/2)
        ecen,esh=lens(u1),lens(v1)
        def charge(x,y):return x+y+2*x*y/d
        def height(a,e):return sqrt_up(4*a*(1-a)*e*(1+e))
        horizontal=u1-v0+esh*(1-2*v0)
        horizontal=max(horizontal,-d*(u0-v1)+ecen*(1-2*u0))
        seam=min(u1+ecen+v1+esh,sqrt_up(horizontal**2+(height(u1,ecen)+height(v1,esh))**2),
                 charge(ecen,esh)+u1+v1-2*d*u0*v0)
        # Test the probability measure assigning equal mass to X and Y as
        # a third class beside the diameter endpoints. Its self-distance
        # contributes the seam. Together with e_X+e_Y >= seam-D(u+v)
        # this bounds the seam and its contribution to the three-edge budget.
        Cjoint=1-d*(1-u1-v1)**2
        for z in zs:
            seam=min(seam,(Cjoint+4*r1*r1/z**2+4*(r1*r1+u1+v1)/z)/(1+4/z))
        for _ in range(7):
            ea,eb=lens(wa/d),lens(wb/d)
            rest=charge(ea,eb)
            T=charge(ecen,esh)+charge(ecen,eb)+charge(esh,eb)
            available=min(T-fixed,seam-d*(u0+v0)+charge(ecen,eb)+charge(esh,eb)-B)
            coef=1+2*eb/d
            for z in zs:
                if z*coef<=4:
                    joint=r1*r1*(1+1/z)+z*(Cjoint-seam)/4
                    available=min(available,seam-d*(u0+v0)+coef*joint+2*eb-B)
            if available<0:return "empty"
            nwa=min(wa,available/2+rest)
            nwb=min(wb,max(nwa,(available+rest)/(2*(1-u1))))
            if (nwa,nwb)==(wa,wb):break
            # Rounding upwards controls denominator growth and preserves bounds.
            nwa=Fraction((nwa*10**7).__ceil__(),10**7)
            nwb=Fraction((nwb*10**7).__ceil__(),10**7)
            wa,wb=nwa,nwb
        # wa,wb are bounds on D*w. Parameter upper bounds use D<=1.
        a0=ea+wa;b0=eb+wb
        va=v1+esh;ca=u1+ecen
        ao_mean=min(a0,ea+rest+max(0,T-2*rest)/(M-1)-r0*r0)
        tw1=a0;tw2=min(2*a0,2*ea+available/2+2*rest)
        A=max(wa,v1)
        C=max(wa,u1)
        rho_full=d-C-wb
        # Each exceptional A vertex has one B neighbor. Thus in the union of
        # the A neighborhoods of two different B vertices it appears at most once.
        bank=min(a0+max(0,(ca+va)/2-a0)/((M-1)//2),
                 ao_mean+(ca+va)/(M-1))
        mixed_full=4*bank+max(2*tw2,ca+tw2+tw1,ca+va+tw2)
        if mixed_full<=rho_full and seam<=(one/4):return "unbalanced"
        rho=d-A-wb
        if rho<=0:return None
        alpha=max(2*a0,va+a0)
        beta=2*b0
        far=min(one,1-d*u0+ecen+b0)
        near=min(one,ca+max(a0,va))
        rho_ordinary=d-wa-wb
        ka=2*far/rho_ordinary
        kb=2*near/rho
        amin=d*u0-A
        bmin=d*(1-u1)-wb
        def endpoint(sh,sc,opposite):
            a,b=sorted((max(0,sh),max(0,sc)))
            return 2 if b==0 else min(2,1+max(0,2*opposite-a)/b)
        # Independent caps on the two Lipschitz differences improve the
        # four-point linear combination when the two distance sums differ.
        lb_c=max(0,d*(u0-v1))+max(0,d*u0-wa)
        lb_b=2*d-v1-wa-2*wb
        ka=min(ka,endpoint(lb_b,lb_c,far))
        kb=min(kb,endpoint(2*rho,2*bmin,near))
        if amin>0:ka=min(ka,max(one,far/rho,far/amin))
        if bmin>0:kb=min(kb,max(one,near/rho,near/bmin))
        # Two cluster errors can be charged in complementary proportions.
        sa=(cap-ka)*rho
        sb=(cap-kb)*rho
        # Only Y=A_1 can have exceptional radius and has one B neighbor.
        bank_a=min(a0+max(0,va-a0)/((M-1)//2),ao_mean+va/((M-1)//2))
        mix_a=8*beta
        mix_b=min(8*alpha,2*(4*bank_a+max(2*tw2,va+tw2+tw1)))
        if sa>=0 and sb>=0 and sa*mix_b+sb*mix_a>=mix_a*mix_b:
            return "balanced"
        return None
    stats=Counter()
    def visit(bounds,depth,subtree):
        if depth>60:
            raise ValueError("subdivision limit exceeded")
        expected=kernel(*[x for b in bounds for x in b])
        if expected:
            if replay is not None and subtree != expected:
                raise ValueError("incorrect leaf category")
            stats[expected]+=1
            stats["depth"]=max(stats["depth"],depth)
            return expected
        if replay is not None:
            if (not isinstance(subtree,list) or len(subtree)!=3
                    or type(subtree[0]) is not int or subtree[0] not in range(3)):
                raise ValueError("missing subdivision")
            j,previous_left,previous_right=subtree
        else:
            scale=[max(9,2*(M-1)*bounds[0][1]),1,1]
            j=max(range(3),key=lambda i:scale[i]*(bounds[i][1]-bounds[i][0]))
            previous_left=previous_right=None
        x,y=bounds[j]
        mid=(x+y)/2
        children=[]
        for interval,previous in (((x,mid),previous_left),((mid,y),previous_right)):
            box=list(bounds)
            box[j]=interval
            children.append(visit(box,depth+1,previous))
        return [j,*children]
    tree=visit([(zero,R),(zero,half),(zero,half)],0,replay)
    return stats,tree


if __name__=="__main__":
    p=ArgumentParser(description=__doc__)
    p.add_argument("--export",type=Path)
    p.add_argument("--replay",type=Path)
    args=p.parse_args()
    previous=json.loads(args.replay.read_bytes()) if args.replay else None
    if previous is not None and previous.get("m_min")!=19:
        raise ValueError("incorrect threshold")
    stats,tree=certify(previous["tree"] if previous is not None else None)
    if args.export:
        args.export.write_bytes(json.dumps({"m_min":19,"tree":tree},separators=(",",":")).encode("ascii"))
    print("All odd orders m >= 19 verified.",dict(stats))
