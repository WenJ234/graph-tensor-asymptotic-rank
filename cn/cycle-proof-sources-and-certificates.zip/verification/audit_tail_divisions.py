"""Replay one tail verifier, checking the result type of every true division."""
import argparse
import ast
from fractions import Fraction
from pathlib import Path
import sys


class CheckDivisions(ast.NodeTransformer):
    def visit_BinOp(self, node):
        self.generic_visit(node)
        if isinstance(node.op, ast.Div):
            call = ast.Call(
                func=ast.Name(id="_checked_division", ctx=ast.Load()),
                args=[node.left, node.right, ast.Constant(node.lineno)],
                keywords=[],
            )
            return ast.copy_location(call, node)
        return node


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("check", choices=("recorded", "independent"))
    mode = parser.parse_args().check
    folder = Path(__file__).resolve().parent
    if mode == "recorded":
        source = folder / "verify_tail_19.py"
        arguments = ["--replay", str(folder.parent / "certificates" / "tail19-tree.json")]
    else:
        source = folder / "check_sharp_independent.py"
        arguments = ["19"]

    divisions = 0

    def checked_division(left, right, line):
        nonlocal divisions
        result = left / right
        if not isinstance(result, Fraction):
            raise ArithmeticError(f"{source.name}:{line} returned {type(result).__name__} from /")
        divisions += 1
        return result

    syntax = CheckDivisions().visit(ast.parse(source.read_text(encoding="utf-8")))
    code = compile(ast.fix_missing_locations(syntax), str(source), "exec")
    sys.argv = [str(source), *arguments]
    exec(code, {"__name__": "__main__", "__file__": str(source),
                "_checked_division": checked_division})
    print(f"{mode}: all {divisions:,} true divisions returned Fraction.")


if __name__ == "__main__":
    main()
