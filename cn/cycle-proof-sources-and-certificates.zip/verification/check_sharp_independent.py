"""Independent large-odd-order verifier. The rounded square roots round up.

Call without --float for a rational proof. The formula derivations are
audited in sharp-audit.md; no producer, derivative estimator or solver
is loaded by this verifier.
"""
from argparse import ArgumentParser
from collections import Counter
from fractions import Fraction
from math import isqrt, sqrt


def verify(M, exact, depth_limit):
    if M<13 or M%2!=1:
        raise ValueError("odd M >= 13 required")
    H, k = M-2, (M-1)//2
    unit = Fraction(1) if exact else 1.
    half = unit/2
    q = 2-unit/k
    def ceil_grid(x, scale=2**28):
        return Fraction((x*scale).__ceil__(),scale) if exact else x
    def radical(x):
        if not exact:
            return sqrt(x)
        scale=2**32
        floor=isqrt((x.numerator*scale**2)//x.denominator)
        return Fraction(floor+(floor*floor*x.denominator < x.numerator*scale**2),scale)
    def error_ratio(r):
        return (2+r-r*r)/(2-2*r)
    R=min(2*unit/7,radical(unit/M))
    for _ in range(3):
        R=min(R,ceil_grid(3*error_ratio(R)/(M-1)))
    trials=[unit/j for j in (1,2,3,4,5,6,7,8)]+[2*unit/3,3*unit/2,2*unit]

    def sufficient(box):
        (r0,r),(u0,u),(v0,v)=box
        if v0>u:
            return "empty"
        u0,v=max(u0,v0),min(v,u)
        D=1-r*r
        B=(r0+r0*r0 if r0*2*H<=1 else (M-1)*r0*r0+unit/(4*H))
        initial=r*error_ratio(r)
        fixed=2*D*u0*v0+B
        if fixed>3*initial:
            return "empty"

        def excess(w):
            w=min(half,w)
            return min(w,(r*r+r*radical(1-D*(1-2*w)**2))/2)
        def err(a,b):
            return a+b+2*a*b/D
        def alt(w,e):
            return radical(4*w*(1-w)*e*(1+e))

        eX,eY=excess(u),excess(v)
        X,Y=u+eX,v+eY
        horizontal=max(u-v0+eY*(1-2*v0),D*(v-u0)+eX*(1-2*u0))
        s=min(X+Y,err(eX,eY)+u+v-2*D*u0*v0,
              radical(horizontal**2+(alt(u,eX)+alt(v,eY))**2))
        joint=1-D*(1-u-v)**2
        for t in trials:
            s=min(s,(t*t*joint+4*r*r+4*t*(r*r+u+v))/(t*t+4*t))
        wa=(5*initial-fixed)/2
        wb=max(wa,(4*initial-fixed)/(2*(1-u)))
        for _ in range(9):
            ea,eb=excess(wa/D),excess(wb/D)
            rest=err(ea,eb)
            other=err(eX,eb)+err(eY,eb)
            three=other+err(eX,eY)
            budget=min(three-fixed,s-D*(u0+v0)+other-B)
            factor=1+2*eb/D
            for t in trials:
                if factor*t<=4:
                    # Write the full expression as an affine function of s.
                    # Its coefficient 1-factor*t/4 is nonnegative.
                    candidate=(1-factor*t/4)*s-D*(u0+v0)+2*eb-B
                    candidate+=factor*(r*r*(1+1/t)+t*joint/4)
                    budget=min(budget,candidate)
            if budget<0:
                return "empty"
            a_next=min(wa,ceil_grid(budget/2+rest))
            b_next=min(wb,ceil_grid(max(a_next,(budget+rest)/(2*(1-u)))))
            if (a_next,b_next)==(wa,wb):
                break
            wa,wb=a_next,b_next

        a,b=wa+ea,wb+eb
        mean_o=min(a,ea+rest+max(0,three-2*rest)/(M-1)-r0*r0)
        two=min(2*a,2*ea+budget/2+2*rest)
        # Weighted mean A-radius, with both exceptional degrees one.
        mean=min(a+max(0,(X+Y)/2-a)/k,mean_o+(X+Y)/(2*k))
        four=max(two*2,X+two+a,X+Y+two)
        rho=D-max(wa,u)-wb
        if rho>0 and 4*mean+four<=rho and s<=unit/4:
            return "unbalanced"

        # Delete X. The only exceptional A row is Y.
        rho=D-max(wa,v)-wb
        if rho<=0:
            return None
        alpha=a+max(a,Y)
        beta=2*b
        dist_f=min(unit,1-D*u0+eX+b)
        dist_n=min(unit,X+max(Y,a))
        low_a=D*u0-max(wa,v)
        low_b=D*(1-u)-wb
        def slope(y,cross,c_min,sum1,sum2):
            lower,larger=sorted([max(0,sum1),max(0,sum2)])
            cost=min(2,2*y/cross)
            if larger>0:
                cost=min(cost,1+max(0,2*y-lower)/larger)
            if c_min>0:
                cost=min(cost,max(unit,y/rho,y/c_min))
            return cost
        ka=slope(dist_f,D-wa-wb,low_a,2*D-v-wa-2*wb,
                 max(0,D*(u0-v))+max(0,D*u0-wa))
        kb=slope(dist_n,rho,low_b,2*rho,2*low_b)
        mean_a=min(a+max(0,Y-a)/k,mean_o+Y/k)
        need_a=8*beta
        need_b=min(8*alpha,2*(4*mean_a+max(2*two,Y+two+a)))
        room_a,room_b=(q-ka)*rho,(q-kb)*rho
        def enough(A,B):
            return min(room_a,room_b)>=0 and room_a*B+room_b*A>=A*B
        if enough(need_a,need_b):
            return "balanced"
        return None

    hist=Counter()
    stack=[(((0*unit,R),(0*unit,half),(0*unit,half)),0)]
    while stack:
        box,depth=stack.pop()
        ok=sufficient(box)
        if ok is not None:
            hist[ok]+=1
            hist["deepest"]=max(hist["deepest"],depth)
            continue
        if depth>=depth_limit:
            return hist,box
        widths=[b-a for a,b in box]
        widths[0]*=max(9,2*(M-1)*box[0][1])
        j=widths.index(max(widths))
        lo,hi=box[j]
        mid=(lo+hi)/2
        for part in ((mid,hi),(lo,mid)):
            stack.append((box[:j]+(part,)+box[j+1:],depth+1))
    return hist,None


if __name__=="__main__":
    cli=ArgumentParser(description=__doc__)
    cli.add_argument("M",type=int)
    cli.add_argument("--float",action="store_true")
    cli.add_argument("--depth",type=int,default=40)
    args=cli.parse_args()
    stats,box=verify(args.M,not args.float,args.depth)
    print(dict(stats),flush=True)
    if box:
        print("Uncovered",box)
        raise SystemExit(1)
