"""Exact finite checks for Euclidean pricing of the five-cycle surgery.

Run with Python 3. No packages are needed. The price calculation invokes
the Euclidean pricing theorem and the planar half-perimeter formula.
"""

from fractions import Fraction
from itertools import product


def crosses(cut, edge):
    a, b = edge
    return int(cut[a] != cut[b])


def cut_size(cut, edges):
    return sum(crosses(cut, edge) for edge in edges)


def check_fixed_surgery():
    # Sites 0,1,2 are the replacement path. The complementary path is 2,3,4,0.
    outside = [(2, 3), (3, 4), (4, 0)]
    local_ranks = [1] * 6 + [2]
    n = 2
    assert sum(local_ranks) == n**3
    for cut in product(range(2), repeat=5):
        p = crosses(cut, (0, 2))
        k = cut_size(cut, outside)
        assert k <= 2 + p
        assert n**k <= sum(r**p for r in local_ranks)
    print("Fixed-seam surgery: all 32 labeled cuts pass; sum r_i = 8")


def check_alternative_seams(n=64, m=5):
    # Target: a cycle. Source: sitewise direct sum of its m one-edge deletions.
    assert m >= 3 and m % 2 == 1
    edges = [(i, (i + 1) % m) for i in range(m)]
    for cut in product(range(2), repeat=m):
        if len(set(cut)) == 1:
            continue
        k = cut_size(cut, edges)
        branch_ranks = [n ** (k - crosses(cut, e)) for e in edges]
        assert max(branch_ranks) == n**k
        assert sum(branch_ranks) >= n**k

    # Unit regular m-gon. Every surviving edge contributes 2/m to H/W per bit.
    target_power = Fraction(2)
    branch_power = Fraction(2 * (m - 1), m)
    # F(target) = n^2, F(source) = m*n^branch_power. Raise to the mth
    # power to perform the strict spectral comparison using integers only.
    assert n ** int(m * target_power) > m**m * n ** int(m * branch_power)
    print(f"C{m}, n={n}: all nontrivial cut ranks pass for the direct sum")
    print(f"Euclidean obstruction: n^{target_power} > {m} * n^({branch_power})")


def check_tree_certificate():
    exponent = Fraction(49, 12)
    for p, crossing in [(Fraction(1, 7), 2), (Fraction(3, 14), 2),
                        (Fraction(3, 7), 4)]:
        assert exponent * 4 * p * (1-p) >= crossing
    print("Tree certificate: all leaf and internal-edge cut costs covered at 49/12")
    # General tree argument. A centroid branch with h leaves gets mass at
    # least (2h-1)/(4k-1), where the odd cycle has 2k+1 labeled leaves.
    # Verify the polynomial identity for sample sizes using exact rationals.
    for k in range(1, 32):
        bound = Fraction((4*k-1)**2, 4*(2*k-1))
        for h in range(1, k+1):
            mass = Fraction(2*h-1, 4*k-1)
            surplus = Fraction(4*(h-1)*(k-h), 2*k-1)
            assert 4*bound*mass*(1-mass) - 2*h == surplus >= 0


if __name__ == "__main__":
    check_fixed_surgery()
    check_alternative_seams()
    check_tree_certificate()
