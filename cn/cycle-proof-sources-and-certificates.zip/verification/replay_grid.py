"""A second exact replay of the grid certificates. Uses only the standard library."""
from argparse import ArgumentParser
from collections import Counter
from fractions import Fraction as Q
from functools import lru_cache
import json
from pathlib import Path

from general_cert import Rules, check, verify as replay_binary


class GridRules(Rules):
    @lru_cache(None)
    def local(self,c):
        n=self.n
        k=n//2
        A=[(c+2*i+1)%n for i in range(k)]
        B=[(c+2*i+2)%n for i in range(k)]
        # Columns are the coefficients of a,b,r,P_A,P_B in the
        # six sufficient inequalities in the manuscript, all <=0.
        K=Q(4,3)
        H=Q(n-2,k)
        V=H-K
        templates=[[-2*K,2,0,K,2],[2,-2*K,0,2,K],
                   [0,2,-2*K,K,2+2*K],[2,0,-2*K,2+2*K,K],
                   [0,0,-V,V,H+V],[0,0,-V,H+V,V]]
        columns=[[self.ix(c,A[0])],[self.ix(c,B[-1])],[self.ix(A[0],B[-1])],
                 [self.ix(A[0],i) for i in A[1:]],[self.ix(B[-1],i) for i in B[:-1]]]
        return [[(idx,f) for group,f in zip(columns,t) if f for idx in group] for t in templates]

    @lru_cache(None)
    def static(self,rule):
        kind,*p=rule
        n=self.n
        if kind=="obj":
            return [(i,-1) for i in self.edges],-self.target
        if kind=="longest-floor":
            return [(self.edges[0],-1)],-self.target/n
        if kind=="longest-bound":
            j,=p
            check(0<j<n,"bad edge")
            return [(self.edges[0],1-n),(self.edges[j],-1)],-self.target
        if kind=="reg":
            c,i,sign=p
            check(0<=c<n and 0<=i<6 and sign in (-1,1),"bad local rule")
            return [(j,v*sign) for j,v in self.local(c)[i]],0
        if kind=="tripod-radius":
            c,=p
            check(0<=c<n,"bad center")
            a,b=(c+1)%n,(c-1)%n
            return ([(self.ix(a,(a+2*i)%n),-1) for i in range(1,n//2)]+
                    [(self.ix(b,(b-2*i)%n),-1) for i in range(1,n//2)], -Q(1,512*(n-2)))
        if kind in ("two-opt","replace","walk"):
            if kind=="walk":
                length,*v=p
                check(length in range(5,n+1,2) and length==len(v) and all(0<=j<n for j in v),"bad walk")
                terms=[(self.ix(i,j),1) for i,j in zip(v,v[1:]+v[:1]) if i!=j]
                if length < n:
                    return terms,Q(length-1)+Q(1,4*(length-2))
                return terms+[(i,-1) for i in self.edges],0
            a,b,c,d=p
            check(len(set(p))==4 and all(0<=j<n for j in p) and b==(a+1)%n,"bad edit")
            if kind=="two-opt":
                check(d==(c+1)%n,"bad two-edge exchange")
                return [(self.ix(a,c),1),(self.ix(b,d),1),(self.ix(a,b),-1),(self.ix(c,d),-1)],0
            check(c==(b+1)%n,"bad replacement")
            return [(self.ix(a,d),1),(self.ix(c,d),1),(self.ix(a,b),-1),(self.ix(b,c),-1)],0
        return super().static(rule)


def verify(document):
    if "grid" not in document:
        return replay_binary(document)
    book=GridRules(document["n"])
    scale=document["grid"]
    check(type(scale) is int and scale>0,"invalid grid")
    dictionary=[tuple(r) for r in document["rules"]]
    check(all(type(x) is int for r in dictionary for x in r[1:]),"noninteger row argument")
    stats=Counter()
    def enforce(rule_id,active):
        check(type(rule_id) is int and 0<=rule_id<len(dictionary),"rule index out of range")
        rule=dictionary[rule_id]
        check(rule[0]!="reg" or rule[1:] in active,"unauthorized regional assumption")
        return rule
    def visit(node,lo,hi,active):
        updates,action=node
        stats["nodes"]+=1
        for op,j,*details in updates:
            check(0<=j<book.dim and all(isinstance(v,int) for v in details),"bad propagation")
            stats["updates"]+=1
            if op in ("g","g2"):
                i,h,tick=details
                triangle=[book.pairs[e] for e in (j,i,h)]
                check(len(set(triangle))==3 and len(set(sum((list(edge) for edge in triangle),[])))==3,
                      "expected a triangle")
                a,b=lo[i],lo[h]
                proposed=Q(tick,scale)
                check(0<=a<=1 and 0<=b<=1 and proposed<=hi[j],"unusable lens endpoints")
                if op=="g":
                    rem=proposed-2+a+b
                    prod=4*(1-a)*(1-b)
                else:
                    check(a+b>1,"invalid angular interval")
                    rem=proposed-a-b+2*a*b
                    prod=4*a*b*(1-a)*(1-b)
                check(rem>=0 and rem**2>=prod,"invalid radical upper bound")
                hi[j]=proposed
                continue
            tick,idx=details
            row,rhs=book.row(enforce(idx,active),lo,hi)
            coeff=Counter()
            for e,v in row:
                coeff[e]+=v
            c=coeff.pop(j,0)
            rhs-=sum(v*(lo[e] if v>=0 else hi[e]) for e,v in coeff.items())
            proposed=Q(tick,scale)
            if op=="l":
                check(c<0 and lo[j]<=proposed<=rhs/c,"invalid lower propagation")
                lo[j]=proposed
            else:
                check(op=="u" and c>0 and rhs/c<=proposed<=hi[j],"invalid upper propagation")
                hi[j]=proposed
        kind,*args=action
        stats[kind]+=1
        if kind=="x":
            check(not args and any(x>y for x,y in zip(lo,hi)),"nonempty exclusion")
            return
        check(all(x<=y for x,y in zip(lo,hi)),"reversed interval")
        if kind=="s":
            i,tick,L,R=args
            mid=Q(tick,scale)
            check(0<=i<book.dim and lo[i]<mid<hi[i],"bad bisection")
            newhi,newlo=hi.copy(),lo.copy()
            newhi[i]=newlo[i]=mid
            visit(L,lo.copy(),newhi,active)
            visit(R,newlo,hi.copy(),active)
        elif kind=="r":
            c,*children=args
            check(0<=c<book.n and len(children)==6,"incomplete regional cover")
            prefix=set(active)
            for i,subtree in enumerate(children):
                visit(subtree,lo.copy(),hi.copy(),prefix|{(c,i,-1)})
                prefix.add((c,i,1))
        elif kind=="z":
            c,=args
            check(0<=c<book.n,"bad local center")
            for row in book.local(c):
                check(sum(v*(hi[j] if v>0 else lo[j]) for j,v in row)<=0,"invalid regional leaf")
        else:
            terms,=args
            check(kind in ("b","e"),"unknown terminal action")
            for idx,num,den in terms:
                enforce(idx,active)
            val=book.value(dictionary,terms,lo,hi,empty=(kind=="e"))
            check(val<0 if kind=="e" else val<=book.target,"unsupported dual bound")
    visit(document["tree"],[Q(0)]*book.dim,[Q(1)]*book.dim,frozenset())
    return book.target,dict(stats)

if __name__=="__main__":
    parser=ArgumentParser(description=__doc__)
    parser.add_argument("certificate",type=Path)
    args=parser.parse_args()
    print(verify(json.loads(args.certificate.read_text(encoding="ascii"))))
