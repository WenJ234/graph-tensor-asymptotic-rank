The Exact Asymptotic Rank Exponents of Cycle Graph Tensors
Wen Jiang
November 26, 2026

Read the PDF for the theorem, assumptions and proofs. The main verification
command runs entirely offline using the Python standard library. Use Python
3.9 or newer, without -O, from this directory.

    python -B verify_all.py

This checks the SHA-256 file manifest, the surgery and Euclidean prices, coefficient and flattening examples,
both original C5 verifiers, and two separately written rational verifiers
for each fixed order from 7 to 17. It then replays the recorded uniform
three-variable proof and checks the same infinite range independently. The
program rejects a missing intermediate odd order or a short-walk rule whose
order has not yet been certified. The uniform checks may take several minutes.

For a shorter run restricted to the fixed orders:

    python -B verify_all.py --finite-only

To run any one of the checks:

    python baseline/verify_c5_exact.py baseline/c5_certificate.json
    python baseline/verify_certificate_independent.py baseline/c5_certificate.json
    python verification/replay_grid.py certificates/c13-exact.json
    python verification/check_odd_independent.py certificates/c13-exact.json
    python verification/verify_tail_19.py --replay certificates/tail19-tree.json
    python verification/check_sharp_independent.py 19

The two finite checkers verify linear implications for real distances on
closed boxes with rational endpoints. In the tail, the parameters r, u, v
are continuous. The integer order is bounded symbolically and does not have
to be enumerated above 19. Certificate discovery is separate from replay.

The optional search directory contains the LP-based discovery programs.
These require NumPy, SciPy and SymPy; solver choice and version can change
the tree and multipliers. Examples, run in a directory where you can write:

    python search/produce_long_cert.py 7 regenerated7.json
    python search/general-pricing/generate9.py regenerated9.json --n 9 --regions --grid-bits 22
    python search/general-pricing/generate9.py regenerated11.json --n 11 --regions --strong --grid-bits 22
    python search/general-probe11/produce_sparse.py 13 regenerated13.json
    python verification/verify_tail_19.py --export regenerated-tail.json

Orders 15 and 17 use the same sparse command with the order changed. Always
verify a newly generated certificate with both readers. Re-running a search
is optional. No assertion in the paper rests on numerical optimization.

The five-cycle benchmark is reproduced from Wen Jiang's public repository
at commit 94fc1dda0964abe138188cfc5c985bbd0c482f3b:
https://github.com/WenJ234/graph-tensor-asymptotic-rank/tree/94fc1dda0964abe138188cfc5c985bbd0c482f3b/c5
The source theorem for the rectangular exponent is pinned to
https://github.com/openai/math/blob/3344da59991ed94f9ba711217b29c1d760badfa6/lean/OAI/LinearAlgebra/SpectralBooks/ExactExponent.lean
The curvature theorem is Theorem 4.3 of
https://github.com/openai/math/blob/3344da59991ed94f9ba711217b29c1d760badfa6/preprints/Euclidean-geometry-in-the-asymptotic-spectrum-of-tensors-November-24-2026/paper.pdf
Zhou's spectral copositivity inequality is Lemma 5.1 of
https://arxiv.org/html/2610.34273v3
The paper gives the role of each cited theorem. The external Lean library
is an input to the mathematical argument and is not rebuilt by this package.

To typeset the manuscript, run the following command twice:

    xelatex -interaction=nonstopmode -halt-on-error paper.tex
