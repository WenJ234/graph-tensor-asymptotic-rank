"""Verify the finite certificates and the uniform tail in dependency order."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess
import sys


ROOT=Path(__file__).resolve().parent


def run(script,*args):
    subprocess.run([sys.executable,"-B",str(ROOT/script),*map(str,args)],cwd=ROOT,check=True)


def main():
    if not __debug__:
        raise RuntimeError("Use standard Python execution so all certificate assertions are enabled.")
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--finite-only",action="store_true",help="check only the finite certificates")
    args=parser.parse_args()
    manifest=json.loads((ROOT/"SHA256.json").read_text(encoding="ascii"))
    for required in ("paper.tex", "cycle-graph-tensors-Wen-Jiang.pdf"):
        if required not in manifest:
            raise ValueError("Missing SHA-256 entry for " + required)
    for name,expected in manifest.items():
        digest=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
        if digest!=expected:
            raise ValueError("SHA-256 mismatch in "+name)
    print(f"SHA-256 digests match for {len(manifest)} files, including the paper PDF and LaTeX source.",flush=True)
    print("Checking the folding identities and the five-cycle benchmark.",flush=True)
    run("verification/verify_cycle_basics.py")
    run("verification/verify_surgery.py")
    run("verification/verify_pricing.py")
    run("baseline/verify_c5_exact.py", "baseline/c5_certificate.json")
    run("baseline/verify_certificate_independent.py","baseline/c5_certificate.json")
    proved={3,5}  # square matrix multiplication theorem; replayed five-point theorem
    for n in range(7,19,2):
        name=f"certificates/c{n}-exact.json"
        document=json.loads((ROOT/name).read_text(encoding="ascii"))
        if document["n"]!=n:
            raise ValueError("certificate order mismatch")
        need={r[1] for r in document["rules"] if r[0]=="walk" and r[1]<n}
        if any(r[0]=="c5" for r in document["rules"]):
            need.add(5)
        if not need<=proved:
            raise ValueError("unverified smaller-walk assumption")
        print(f"C{n}: replaying both rational checkers; shorter certified orders {sorted(need)}.",flush=True)
        run("verification/replay_grid.py",name)
        run("verification/check_odd_independent.py",name)
        proved.add(n)
    tail_file="certificates/tail19-tree.json"
    first=json.loads((ROOT/tail_file).read_text(encoding="ascii"))["m_min"]
    if first!=19 or set(range(3,first,2))!=proved:
        raise ValueError("gap between finite orders and the uniform proof")
    if args.finite_only:
        print("Finite orders 3 through 17 covered. Uniform tail checks were skipped.")
        return
    print("Verifying all odd orders n >= 19 with the recorded tree and an independent subdivision.",flush=True)
    with ThreadPoolExecutor(max_workers=2) as pool:
        frozen = pool.submit(run,"verification/verify_tail_19.py","--replay",tail_file)
        independent = pool.submit(run,"verification/check_sharp_independent.py","19")
        frozen.result()
        independent.result()
    print("All odd orders n >= 3 are covered. Even orders follow by the alternating flattening.")


if __name__=="__main__":
    main()
