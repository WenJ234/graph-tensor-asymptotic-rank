from pathlib import Path
import numpy as np
from matplotlib import pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch
from matplotlib import rcParams
rcParams.update({'font.family':'DejaVu Sans','mathtext.fontset':'stix','pdf.fonttype':42})
fig,ax=plt.subplots(figsize=(6.55,1.72))
ax.set_xlim(-1.52,5.35); ax.set_ylim(-1.05,1.09);ax.set_aspect('equal');ax.axis('off')
coord=[(.83*np.cos(np.pi/2-2*np.pi*i/5),.83*np.sin(np.pi/2-2*np.pi*i/5)) for i in range(5)]
colors={'A':'#285b73','B':'#9a5430','C':'#47584b'}
groups='ABABC'
def dot(xy,lab):
    ax.add_patch(Circle(xy,.144,fc=colors[lab],ec='white',lw=.8,zorder=2))
    ax.text(*xy,lab,ha='center',va='center',color='white',size=8.3,fontweight='semibold',zorder=3)
for i,xy in enumerate(coord):
    end=coord[(i+1)%5]
    ax.plot([xy[0],end[0]],[xy[1],end[1]],lw=1.35,color='#56666a',zorder=0)
    dot(xy,groups[i])
ax.add_patch(FancyArrowPatch((1.05,.02),(2.10,.02),arrowstyle='-|>',mutation_scale=12,color='#53686b',lw=1))
pts={'A':(2.55,-.59),'B':(4.45,-.59),'C':(3.50,.81)}
for u,v,text,position in [('A','C',r'$n$',(2.91,.22)),('B','C',r'$n$',(4.11,.22)),('A','B',r'$n^3$',(3.5,-.82))]:
    x,y=pts[u],pts[v];ax.plot([x[0],y[0]],[x[1],y[1]],color='#526267',lw=1.75 if (u,v)==('A','B') else 1.35,zorder=0)
    ax.text(*position,text,size=11,ha='center',va='center')
for lab,xy in pts.items():dot(xy,lab)
fig.subplots_adjust(left=0,right=1,bottom=0,top=1)
fig.savefig(Path(__file__).with_name('regrouping.pdf'),facecolor='white',metadata={'Title':'Tripartite grouping of the five-cycle','Creator':'Matplotlib'})
