The Exact Asymptotic Rank Exponent of the Five-Cycle Graph Tensor
Wen Jiang
November 26, 2026

paper.tex contains the complete manuscript. The included PDF is the typeset
paper with section bookmarks and three embedded files: the upper-bound
certificate and two independent checkers. The PDF figure regrouping.pdf
belongs beside paper.tex. No network access is required for verification.

1. Check the proof certificate and the tensor identities

From the verification directory, run the following using Python 3.8 or later,
without the -O option. These checks require only the standard library.

    python verify_c5_exact.py
    python verify_certificate_independent.py c5_certificate.json
    python verify_surgery.py 9
    python verify_c5_coefficients.py verify_surgery.py
    python verify_pricing.py

Expected results:
  * Both certificate checkers verify 24 splits, 20 exclusion leaves and
    5 local leaves. The integer checker verifies 50 strict contradictions
    at 51,200 box corners. All numerical certificate comparisons are exact.
  * The surgery yields 7, 31, 127 and 511 terms for lengths 3, 5, 7 and 9.
    The cyclic five-cycle decomposition and the surgery decomposition both
    match all 1,024 entries: 32 ones and 992 zeros.
  * For the five-cycle with edge dimension 64, every bipartition rank
    inequality holds for the proposed direct-sum source. Its value under
    the regular-pentagon Euclidean spectral point is strictly below the
    target's value.

The distributed c5_certificate.json has 13,054 bytes and SHA-256
e73ce6a76517069e1bc6f9c26e3b1616886ce3de31cc626ccbdbf25dea84e07e.
The appendix specifies the proof format and works through one leaf by hand.

2. Optional certificate search

With NumPy and SciPy installed, run from verification:

    python generate_certificate.py regenerated.json
    python verify_c5_exact.py regenerated.json
    python verify_certificate_independent.py regenerated.json

Search uses linear programming. The resulting certificate is checked in
exact arithmetic. Different solvers or versions can produce different
valid trees or multipliers.

3. Rebuild the paper

From the directory containing paper.tex:

    xelatex -interaction=nonstopmode -halt-on-error paper.tex
    xelatex -interaction=nonstopmode -halt-on-error paper.tex

The manuscript uses the standard article class, AMS packages, graphicx,
booktabs, and geometry. The figure is provided as a vector PDF. To redraw
it from the supplied source, run python make_figure.py with Matplotlib and
NumPy installed before compiling.

To add the PDF bookmarks, authorship metadata, and attachments, install
pypdf (tested with 6.21.4) and run:

    python prepare_pdf.py paper.pdf paper-with-certificate.pdf

4. Scope of verification and cited results

The checkers certify the finite five-point covering argument and the finite
identities described above. The proof also invokes Strassen spectral
duality, Zhou's copositivity inequality, the exact rectangular exponent,
and the CAT(0) curvature and Euclidean pricing theorems. These inputs appear
with their hypotheses and sources in the paper. No external Lean build is
required to run the distributed scripts. The November 2026 sources for the
rectangular exponent and spectral geometry are pinned to repository commit
3344da59991ed94f9ba711217b29c1d760badfa6.

Rectangular theorem and scope:
https://github.com/openai/math/blob/3344da59991ed94f9ba711217b29c1d760badfa6/lean/docs/107.md
Euclidean pricing and curvature:
https://github.com/openai/math/blob/3344da59991ed94f9ba711217b29c1d760badfa6/preprints/Euclidean-geometry-in-the-asymptotic-spectrum-of-tensors-November-24-2026/paper.pdf
Copositivity and the earlier odd-cycle bound:
https://arxiv.org/html/2610.34273v3
