"""Add section bookmarks and the exact proof certificate to the typeset paper."""
import argparse
from pathlib import Path
import re

from pypdf import PdfWriter


SECTIONS = [
    ("sec:pre", "2. Tensors, spectral points, and rectangular grouping"),
    ("sec:metric", "3. Five-point metric optimization"),
    ("sec:certificate", "4. Global certificate and equality cases"),
    ("sec:odd", "5. Odd cycles and tree wire metrics"),
    ("sec:surgery", "6. Odd-cycle surgery and finite ranks"),
    ("sec:flat", "7. Euclidean prices of surgery branches"),
    ("sec:open", "8. Further questions"),
    ("app:certificate", "Appendix A. Certificate format and a worked leaf"),
    ("sec:references", "References"),
]
ATTACHMENTS = (
    "c5_certificate.json",
    "verify_c5_exact.py",
    "verify_certificate_independent.py",
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_pdf", type=Path)
    parser.add_argument("output_pdf", type=Path)
    args = parser.parse_args()
    if args.input_pdf.resolve() == args.output_pdf.resolve():
        parser.error("choose an output path different from the typeset input")
    aux = args.input_pdf.with_suffix(".aux").read_text(encoding="utf-8")
    page_labels = dict(re.findall(r"\\newlabel\{([^}]+)\}\{\{[^}]*\}\{(\d+)\}", aux))
    writer = PdfWriter(clone_from=str(args.input_pdf))
    writer.add_metadata({
        "/Title": "The Exact Asymptotic Rank Exponent of the Five-Cycle Graph Tensor",
        "/Author": "Wen Jiang",
        "/Subject": "Five-point metric optimization and the asymptotic rank of odd-cycle graph tensors",
        "/Keywords": "graph tensors, asymptotic rank, Ptolemy inequality, tensor surgery",
    })
    writer.add_outline_item("1. Introduction and main theorem", 0)
    for label, title in SECTIONS:
        writer.add_outline_item(title, int(page_labels[label]) - 1)
    verification = Path(__file__).resolve().parent / "verification"
    for name in ATTACHMENTS:
        writer.add_attachment(name, (verification / name).read_bytes())
    with args.output_pdf.open("wb") as stream:
        writer.write(stream)


if __name__ == "__main__":
    main()
