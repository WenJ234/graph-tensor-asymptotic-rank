"""Generate and check a rational upper-bound certificate for the five-cycle.

Run python generate_certificate.py [output.json]. NumPy, SciPy (HiGHS),
and the neighboring verify_c5_exact.py are required. The default output
is regenerated_certificate.json in the caller's current directory.
"""

import argparse
import json
from functools import reduce
from itertools import combinations, permutations, product
from math import gcd
from pathlib import Path

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csr_matrix, hstack

import verify_c5_exact as verifier


VERTICES = range(5)
DIM = len(verifier.PAIRS)
TARGET = 49 / 12


def copositive_test(distances):
    """Find a violated test by looking for stationary points on simplex faces."""
    matrix = np.zeros((5, 5))
    for (i, j), value in zip(verifier.PAIRS, distances):
        matrix[i, j] = matrix[j, i] = value
    best_value, best_weights = 0.0, None
    for size in range(2, 6):
        for face in combinations(VERTICES, size):
            submatrix = matrix[np.ix_(face, face)]
            system = np.ones((size + 1, size + 1))
            system[:-1, :-1] = submatrix
            system[-1, -1] = 0
            rhs = np.zeros(size + 1)
            rhs[-1] = 1
            try:
                weights = np.linalg.solve(system, rhs)[:-1]
            except np.linalg.LinAlgError:
                continue
            if weights.min() < -1e-10:
                continue
            value = 2 * (weights @ submatrix @ weights)
            if value > best_value:
                best_weights = np.zeros(5)
                best_weights[list(face)] = weights
                best_value = value
    if best_value <= 1.000001:
        return None
    return ("cp", *(int(v) for v in np.rint(best_weights * 10000)))


class CertificateSearch:
    def __init__(self):
        self.rules = []
        self.rule_ids = {}
        self.base = [
            self.register(("tri", i, j, k))
            for i, j, k in permutations(VERTICES, 3) if i < k
        ]
        self.base.extend(self.register(("sym", 0, j)) for j in range(1, 5))
        self.base.append(self.register(("sym", 1, 4)))
        for pattern in [
            (3, 3, 3, 3, 2), (1, 1, 1, 1, 1), (2, 2, 1, 1, 1),
            (3, 3, 1, 0, 0), (1, 1, 1, 0, 0), (3, 3, 2, 1, 1),
        ]:
            for weights in sorted(set(permutations(pattern))):
                self.base.append(self.register(("cp", *weights)))
        self.ptolemy = [
            self.register(("pt", q, *ends))
            for q in range(len(verifier.QUADS)) for ends in product((0, 1), repeat=3)
        ]
        self.target = self.register(("target",))
        self.outside = [
            [self.register(("outside", c, t)) for t in range(len(verifier.local_tests(c)))]
            for c in VERTICES
        ]
        self.objective = np.zeros(DIM)
        self.objective[verifier.DIAGS] = -1  # linprog minimizes

    def register(self, rule):
        if rule not in self.rule_ids:
            self.rule_ids[rule] = len(self.rules)
            self.rules.append(rule)
        return self.rule_ids[rule]

    def system(self, ids, lo, hi):
        matrix = np.zeros((len(ids), DIM))
        rhs = np.empty(len(ids))
        for row, rule_id in enumerate(ids):
            terms, rhs[row] = verifier.inequality(self.rules[rule_id], lo, hi)
            for col, coef in terms:
                matrix[row, col] += coef
        scales = np.maximum(1, np.maximum(np.max(np.abs(matrix), axis=1), np.abs(rhs)))
        return csr_matrix(matrix / scales[:, None]), rhs / scales, scales

    def contradiction(self, ids, lo, hi):
        # Minimize one common relaxation of all inequalities. A positive
        # optimum produces nonnegative multipliers from the LP dual.
        matrix, rhs, scales = self.system(ids, lo, hi)
        relaxed = hstack([matrix, -np.ones((len(ids), 1))], format="csr")
        result = linprog(
            np.r_[np.zeros(DIM), 1.0], A_ub=relaxed, b_ub=rhs,
            bounds=[*zip(lo, hi), (None, None)], method="highs",
        )
        if not result.success or result.fun < 1e-9:
            return None
        multipliers = -result.ineqlin.marginals / scales
        terms = [
            [rule_id, integer] for rule_id, weight in zip(ids, multipliers)
            if (integer := round(float(weight) * 10**28)) > 0
        ]
        common = reduce(gcd, (weight for _, weight in terms), 0)
        return [[rule_id, weight // common] for rule_id, weight in terms] or None

    def visit(self, lo, hi, depth=0):
        if depth > 170:
            raise RuntimeError("LP search exceeded its subdivision depth")
        for _ in range(6):
            ids = self.base + self.ptolemy
            matrix, rhs, _ = self.system(ids, lo, hi)
            optimum = linprog(
                self.objective, A_ub=matrix, b_ub=rhs,
                bounds=list(zip(lo, hi)), method="highs",
            )
            if not optimum.success or -optimum.fun < TARGET - 1e-8:
                proof = self.contradiction(ids + [self.target], lo, hi)
                if proof is not None:
                    return ["empty", proof]
                if not optimum.success:
                    raise RuntimeError(optimum.message)
            point = optimum.x
            rule = copositive_test(point)
            if rule is None:
                break
            rule_id = self.register(rule)
            if rule_id in self.base:
                break
            self.base.append(rule_id)

        for center in VERTICES:
            tests = verifier.local_tests(center)
            if min(3 * (point[i] + point[j]) - 4 * point[k] for i, j, k in tests) < 0.005:
                continue
            proofs = []
            for outside in self.outside[center]:
                proof = self.contradiction(ids + [self.target, outside], lo, hi)
                if proof is None:
                    break
                proofs.append(proof)
            if len(proofs) == len(tests):
                return ["local", center, proofs]

        # Split where the interval leaves the widest product relaxation.
        gap = (hi - point) * (point - lo)
        axis = int(np.argmax(gap + 0.015 * (hi - lo)))
        left_hi, right_lo = hi.copy(), lo.copy()
        left_hi[axis] = right_lo[axis] = (lo[axis] + hi[axis]) / 2
        return ["split", axis, self.visit(lo, left_hi, depth + 1),
                self.visit(right_lo, hi, depth + 1)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path, nargs="?",
                        default=Path("regenerated_certificate.json"))
    args = parser.parse_args()
    search = CertificateSearch()
    tree = search.visit(np.zeros(DIM), np.ones(DIM))
    document = {"rules": search.rules, "tree": tree}
    counts = verifier.verify(document)
    args.output.write_text(json.dumps(document, separators=(",", ":")), encoding="ascii")
    print(f"Verified {counts[0]} splits, {counts[1]} excluded boxes, {counts[2]} local boxes.")
    print(f"Wrote {args.output.resolve()}")


if __name__ == "__main__":
    main()
