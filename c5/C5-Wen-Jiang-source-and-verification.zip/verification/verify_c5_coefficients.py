"""Check both published 31-term constructions on the full matrix-unit basis.

The three seed terms below transcribe Buhrman--Christandl--Zuiddam, ITCS 2017,
Theorem 19. If supplied, the trusted Python surgery module provides the second
list of simple tensors. Its coefficient-testing routines are never invoked.

Run: python verify_c5_coefficients.py [verify_surgery.py]
"""
from argparse import ArgumentParser
from collections import Counter
from itertools import product
from math import prod
from pathlib import Path
from runpy import run_path


def outer(left, right):
    return tuple(a * b for a in left for b in right)


def symmetric_terms():
    zero, one = (1, 0), (0, 1)
    plus, minus = (1, 1), (1, -1)
    identity = (1, 0, 0, 1)
    zz, zo, oz, oo = [outer(x, y) for x, y in product((zero, one), repeat=2)]
    minus_zero, zero_plus = outer(minus, zero), outer(zero, plus)
    seeds = [(minus_zero, zz, zz, zero_plus, oo),
             (minus_zero, zo, oz, zero_plus, oo),
             (identity, oo, minus_zero, zero_plus, oo)]
    terms = [(1, (identity,) * 5)]
    for seed in seeds:
        for term in (seed, tuple(v[::-1] for v in seed)):
            for shift in range(5):
                terms.append((-1, term[shift:] + term[:shift]))
    return terms


def verify(label, signed_terms):
    if len(signed_terms) != 31:
        raise ValueError(label + " needs 31 simple tensors")
    values = Counter()
    for index in product(range(4), repeat=5):
        # tr(E_i E_j E_k E_l E_m) in lexicographic matrix-unit coordinates.
        trace = int(all(index[t - 1] % 2 == index[t] // 2 for t in range(5)))
        entry = sum(sign * prod(vector[j] for vector, j in zip(term, index))
                    for sign, term in signed_terms)
        if entry != trace:
            raise ValueError(f"{label}: coefficient {index} equals {entry}, expected {trace}")
        values[entry] += 1
    print(f"{label}: 31 simple tensors; all 1024 trace coefficients agree; "
          f"{values[1]} ones, {values[0]} zeros")


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("surgery_module", nargs="?", type=Path)
    module = parser.parse_args().surgery_module
    verify("BCZ cyclic symmetrization", symmetric_terms())
    if module is not None:
        surgery = run_path(str(module))
        terms = [(1, triple + old[1:]) for old in surgery["STRASSEN"]
                 for triple in surgery["open_vertex"](old[0])]
        verify("CZ vertex surgery", terms)
