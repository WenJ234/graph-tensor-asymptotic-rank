"""Replay the weighted-cycle certificates included with this paper."""
import argparse
import hashlib
import subprocess
import sys
import tempfile
from pathlib import Path
from zipfile import ZipFile


ARCHIVE = Path(__file__).resolve().with_name("certificates.zip")
DIGEST = "0ca66edd120486e987a09b7a82ed9f6b004298b8e5d67412f1c5f162bea5af17"
COMMANDS = {
    "all": (".", "verify.py"),
    "examples": ("comparisons", "verify.py"),
    "threshold": ("threshold", "verify.py"),
    "polar": ("seven_polar", "verify.py"),
    "nine": ("general_nine", "check_marked9_parallel.py", "nine-marked.json.gz"),
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("component", choices=COMMANDS, nargs="?", default="all")
    parser.add_argument("--workers", type=int, default=4, help="nine-cycle processes")
    parser.add_argument("--gmp", action="store_true", help="use installed gmpy2 for nine")
    args = parser.parse_args()
    if sys.version_info < (3, 10) or not __debug__:
        parser.error("use Python 3.10 or later with assertions enabled")
    if args.workers < 1 or (args.gmp and args.component != "nine"):
        parser.error("supply a positive worker count and use --gmp only with nine")
    if hashlib.sha256(ARCHIVE.read_bytes()).hexdigest() != DIGEST:
        raise SystemExit("The certificate archive differs from the frozen release.")
    folder, *command = COMMANDS[args.component]
    if args.component == "nine":
        command.extend(("--workers", str(args.workers)))
        if args.gmp:
            command.append("--gmp")
    with tempfile.TemporaryDirectory(prefix="weighted-cycle-") as tmp:
        with ZipFile(ARCHIVE) as archive:
            archive.extractall(tmp)
        subprocess.run([sys.executable, "-B", *command],
                       cwd=Path(tmp) / folder, check=True)


if __name__ == "__main__":
    main()
