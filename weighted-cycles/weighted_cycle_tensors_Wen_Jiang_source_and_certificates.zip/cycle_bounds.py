"""Exact asymptotic rank exponent of complex weighted cycle tensors."""
from argparse import ArgumentParser
from fractions import Fraction as F
from math import isqrt, prod


def log_bounds(q, bits):
    """Dyadic enclosure of log2(q) by normalized squaring with outward rounding."""
    k = q.bit_length() - 1
    if q == 1 << k:
        return F(k), F(k)
    precision = 2 * bits + 16
    while True:
        unit = 1 << precision
        den = 1 << k
        lo = (q * unit) // den
        hi = (q * unit + den - 1) // den
        digits = 0
        for _ in range(bits):
            lo = lo * lo // unit
            hi = (hi * hi + unit - 1) // unit
            digits *= 2
            if lo >= 2 * unit:
                digits += 1
                lo //= 2
                hi = (hi + 1) // 2
            elif hi >= 2 * unit:
                break
        else:
            base = F(k) + F(digits, 1 << bits)
            return base, base + F(1, 1 << bits)
        precision *= 2


def omega(x, y, z):
    x, y, z = sorted((x, y, z), reverse=True)
    if not z:
        return x + y
    correction = max(F(0), (x + y) * z - x * y)
    return x + y + correction**2 / (4 * x * y * z)


def folds(w):
    total = sum(w)
    pairs = zip(w, w[1:] + w[:1])
    return [omega(total - a - b, a, b) for a, b in pairs]


def compute(lo, hi):
    if len(lo) % 2 == 0 or min(hi) == 0:
        return 'S', sum(lo), sum(hi)
    return 'L3', max(folds(lo)), max(folds(hi))


def cut_certified(lo, hi, bits):
    # B(x,y,z)>=m iff each coordinate is >=m and the sum of the three
    # square roots of products of coordinate excesses is >=m.
    m = min(hi)
    if lo == hi:
        return max(folds(lo)) == sum(lo)-m
    grid = 1 << (bits+8)
    total = sum(lo)
    for i, a in enumerate(lo):
        b = lo[(i+1) % len(lo)]
        x, y, z = (max(F(0),v-m) for v in (total-a-b, a, b))
        def root_lower(value):
            return F(isqrt(value.numerator*grid*grid // value.denominator),grid)
        if root_lower(x*y)+root_lower(y*z)+root_lower(z*x) < m:
            return False
    return True


def fixed_decimal(integer, places):
    unit = 10**places
    return f'{integer//unit}.{integer%unit:0{places}d}'


def main():
    parser = ArgumentParser(description=__doc__)
    data = parser.add_mutually_exclusive_group(required=True)
    data.add_argument('--weights', nargs='+', type=F, help='nonnegative rational log2 weights')
    data.add_argument('--dims', nargs='+', type=int, help='positive integer edge dimensions')
    parser.add_argument('--bits', type=int, default=48, help='fractional log bits (default 48)')
    args = parser.parse_args()
    dims = args.dims is not None
    order = args.dims if dims else args.weights
    if len(order)<3 or args.bits<1 or min(order)<(1 if dims else 0):
        parser.error('need >=3 edges, valid dimensions or weights, and positive --bits')
    if dims:
        lo,hi = (list(v) for v in zip(*(log_bounds(q,args.bits) for q in order)))
    else:
        lo,hi = order,order
    formula,lb,ub = compute(lo,hi)
    if formula=='S':
        print('Gamma = S = sum_i w_i.')
    else:
        print('Gamma = L3 = max_i Omega(S-w_i-w_(i+1), w_i, w_(i+1)).')
    if dims and (formula=='S' or cut_certified(lo,hi,args.bits)):
        exact_rank = prod(order) if formula=='S' else prod(order)//min(order)
        print(f'Asymptotic rank = {exact_rank}. Gamma = log2({exact_rank}).')
        lb,ub = log_bounds(exact_rank,args.bits)
    print(f'Gamma = {lb}' if lb==ub else f'{lb} <= Gamma <= {ub}')
    if lb != ub:
        places = 10
        lower = fixed_decimal((lb*10**places).__floor__(),places)
        upper = fixed_decimal((ub*10**places).__ceil__(),places)
        print(f'{lower} <= Gamma <= {upper} (outward rounded)')
    if formula=='L3' and lb!=ub:
        print('The formula is exact; the printed rationals enclose its numerical value.')


if __name__=='__main__':
    main()
