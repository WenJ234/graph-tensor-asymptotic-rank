# The Asymptotic Rank of Weighted Cycle Tensors

**Wen Jiang**

This project contains the complete English manuscript and the computational material supporting its proofs over the complex numbers.

## Build the paper

From this directory run the following commands with a recent TeX Live or MiKTeX installation.

    pdflatex -interaction=nonstopmode -halt-on-error paper.tex
    pdflatex -interaction=nonstopmode -halt-on-error paper.tex

The bibliography is part of the LaTeX source. No BibTeX run is necessary. The manuscript uses the `article` class, `lmodern`, `amsmath`, `amssymb`, `amsthm`, `mathtools`, `array`, `booktabs`, `tabularx`, `geometry`, `fontenc`, `xcolor` and `hyperref`.

## Reproduce an exponent

    python -B cycle_bounds.py --dims 4 4 4 4 8
    python -B cycle_bounds.py --dims 6 9 7 7 7 7 9
    python -B cycle_bounds.py --weights 1 3/2 2 7/4 1

Use `--dims` for integer edge dimensions and `--weights` for rational base-two logarithmic weights. The order of the entries is their cyclic order. `--bits` controls the precision of rigorously enclosed binary logarithms. The examples include a noninteger exponent, an input with dimensions other than powers of two and exact asymptotic rank 194481, and arbitrary rational weights. `weighted_cycle_comparison.csv` gives 29 independently checked comparisons with maximum cuts and Zhou's relaxation. Each digit in the first column is one logarithmic edge weight.

## Reproduce the proof certificates

Use Python 3.10 or later with assertions enabled. The complete replay includes a C11 program using signed 128-bit integers and undefined-behavior checks. Install a compatible Clang, GCC or Zig, or point `CYCLE_CC` to the compiler executable. This compiler is used in the pentagon consecutive-contact proof. No linear programming solver, network connection or external theorem prover is needed for replay. The nine-cycle component optionally supports `gmpy2` for faster rational arithmetic.

    python -B verify.py

The wrapper verifies the SHA-256 digest, extracts `certificates.zip` into a temporary directory and runs the aggregate checker. That checker also extracts the two earlier verification archives under `preceding/`. The complete replay includes further checks beyond the shortest dependency path through the paper. The frozen archive preserves the original checkers, proof trees and historical supporting notes.

To run selected checks independently from the same project root:

    python -B verify.py examples
    python -B verify.py polar
    python -B verify.py threshold
    python -B verify.py nine --workers 4

The optional nine-cycle acceleration is selected with `python -B verify.py nine --workers 4 --gmp`. To inspect the certificate files, extract `certificates.zip` into a separate directory. Its `verify.py` lists the individual invocations. Among the directories referenced in the paper:

| Directory | Content |
|---|---|
| `threshold`, `conditional_nine`, `adjacent` | Three-coordinate bounds, including the unbounded normalized total, large diameter and adjacent minima |
| `five_disjoint`, `five_consecutive`, `five_isolated` | Three strict contact configurations in the pentagon |
| `five_plateau` | A unique-minimum flat branch on the designated continuous parameter box |
| `preceding/odd_cycle_supplement_checks.zip` | Includes the `c5_two_light_all` binary family used in the English proof |
| `conditional_seven`, `marked_words`, `seven_marked_radius` | Seven-cycle large-diameter and ordered-contact cases |
| `seven_polar` | All 3,432 candidate bases and seven interval trees for the complementary seven-cycle diameter range |
| `general_nine` | Five-parameter nine-cycle tree with 213,816 leaves |
| `comparisons` | Exact sample and relaxation checks, including the `(4,4,4,4,8)` benchmark |

The root domains, geometric implications, symmetry reductions and rational leaf tests appear in the manuscript. The unweighted odd-cycle theorem, rectangular matrix multiplication exponent and spectral curvature theorem are external results cited there.
