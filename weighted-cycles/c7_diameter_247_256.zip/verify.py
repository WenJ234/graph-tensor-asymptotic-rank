"""Exact proof for seven distances around a cycle at diameter at most 247/256."""
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations, permutations
from pathlib import Path
import gzip
import json

CAP = Q(247, 256)
ALPHA = Q(7, 19)
CHECKSUM = "dc14512d2bb59fcb75ede6cc1ccf4f45339bf10b94c1e4fd4a68b62d875c606a"
PAIRS = list(combinations(range(7), 2))
INDEX = {p:i for i,p in enumerate(PAIRS)}

def index(a, b):
    return INDEX[tuple(sorted((a,b)))]

EDGES = [index(i, (i+1)%7) for i in range(7)]
SYMMETRY = {(e, EDGES[0]) for e in EDGES[1:]} | {(EDGES[1], EDGES[-1])}
MATCH = {
    tuple(index(i,j) for i,j in ((a,b),(c,d),(a,c),(b,d),(a,d),(b,c)))
    for a,b,c,d in permutations(range(7),4)
}

def require(value, message):
    if not value:
        raise ValueError(message)

def constraint(rule, lo, hi):
    op,*args = rule
    require(all(type(t) is int for t in args), "non-integer rule arguments")
    if op == "t":
        a,b,c = args
        require(len({a,b,c}) == 3, "triangle uses repeated labels")
        return [(index(a,c),1),(index(a,b),-1),(index(b,c),-1)], 0
    if op == "sym":
        a,b = args
        require((a,b) in SYMMETRY, "invalid symmetry assumption")
        return [(a,1),(b,-1)], 0
    if op == "cp":
        require(len(args) == 7 and min(args) >= 0 and sum(args)>0, "invalid copositive test")
        s = sum(args)**2
        return [(k,Q(4*args[a]*args[b],s)) for k,(a,b) in enumerate(PAIRS)], 1
    if op == "p":
        indices = args[:6]
        flags = args[6:]
        require(tuple(indices) in MATCH and len(flags)==3 and all(f in (0,1) for f in flags), "invalid Ptolemy envelope")
        row = []
        rhs = 0
        for j,(a,b) in enumerate(zip(indices[::2],indices[1::2])):
            sign = 1 if j==0 else -1
            f = flags[j]
            u = (lo,hi)[f][a]
            v = (lo,hi)[f if j==0 else 1-f][b]
            row.extend(((a,sign*v),(b,sign*u)))
            rhs += sign*u*v
        return row, rhs
    raise ValueError("unknown rule")

def verify():
    raw = Path(__file__).with_name("perimeter.json.gz").read_bytes()
    require(sha256(raw).hexdigest()==CHECKSUM,"unexpected certificate checksum")
    data = json.loads(gzip.decompress(raw))
    require(Q(data["cap"])==CAP,"incorrect initial box")
    objective = [Q(k in EDGES)+(ALPHA if k==EDGES[0] else 0) for k in range(21)]
    stats = Counter()
    rules = data["rules"]
    def visit(node,lo,hi):
        op,*args = node
        stats[op] += 1
        if op == "s":
            axis,left,right = args
            require(type(axis) is int and 0<=axis<21,"invalid bisection")
            mid = (lo[axis]+hi[axis])/2
            lower_right = lo.copy(); lower_right[axis] = mid
            upper_left = hi.copy(); upper_left[axis] = mid
            visit(left,lo,upper_left)
            visit(right,lower_right,hi)
            return
        require(op=="b" and len(args)==1,"invalid terminal node")
        residual = objective.copy()
        bound = Q(0)
        for num,n,d in args[0]:
            require(all(type(x) is int for x in (num,n,d)) and 0<=num<len(rules) and n>0 and d>0,"invalid dual multiplier")
            coeff = Q(n,d)
            terms,rhs = constraint(rules[num],lo,hi)
            bound += coeff*rhs
            for k,a in terms:
                residual[k] -= coeff*a
        bound += sum(y*(hi[k] if y>0 else lo[k]) for k,y in enumerate(residual))
        require(bound<=6+ALPHA,"dual failed")
    visit(data["tree"],[Q(0)]*21,[CAP]*21)
    print("PASS",dict(stats),len(rules),"rules")

if __name__=="__main__":
    verify()
